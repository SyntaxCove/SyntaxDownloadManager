# Third-Party Licenses — Audit Policy & Current Registry

No installer is shipped before this audit is complete for every bundled
component (master prompt §52). Each component below records: component,
version, license, source, and distribution requirements.

## Bundled (packaging time)

| Component                           | Version policy                                | License                                          | Source                   | Distribution requirements                                                                                                                                 |
| ----------------------------------- | --------------------------------------------- | ------------------------------------------------ | ------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| download-core                       | built from this repo                          | MIT                                              | `native/download-core`   | Ship license text with installer                                                                                                                          |
| yt-dlp                              | latest at fetch, pinned in `resources/locks/` | Unlicense                                        | github.com/yt-dlp/yt-dlp | Public-domain dedication; include upstream notice                                                                                                         |
| Deno                                | latest at fetch, pinned                       | MIT                                              | github.com/denoland/deno | Include MIT license text                                                                                                                                  |
| FFmpeg / FFprobe (essentials build) | release build at fetch, pinned                | GPL-3.0-or-later (build includes GPL components) | gyan.dev builds          | **GPL obligations apply**: offer corresponding source; keep FFmpeg separated in `resources/bin/ffmpeg/` with its own license file; do not statically link |
| Electron (runtime)                  | 44.4.5                                        | MIT (with Chromium/Node bundled components)      | electronjs.org           | Electron ships its own license bundle; preserve electron/LICENSES.chromium.html                                                                           |

## npm dependencies (dev + runtime)

Full inventory: `pnpm-lock.yaml`. Notable runtime deps: react/react-dom
(MIT), zustand (MIT), zod (MIT). Dev-only tooling (vite, esbuild, vitest,
eslint stack, typescript, prettier, electron-builder) is not distributed but
is MIT/Apache-2.0/ISC/BSD family — verified before adding new dependencies.

## Rust crates

Inventory: `native/Cargo.lock`. All current crates (tokio, serde,
serde_json, rusqlite+SQLite — SQLite is public domain, tracing stack,
thiserror, chrono) are MIT/Apache-2.0 dual-licensed. Re-audit whenever a
crate is added; record additions here.

## Rules

1. New bundled component ⇒ must be added to `resources/manifest.json` with
   license + source + this table updated, before any packaging run.
2. GPL components must never be merged into non-GPL-compatible code paths;
   they are separate executables invoked as child processes (which this
   architecture already guarantees, ADR-0002).
3. Every installer build re-runs `pnpm resources:verify`; license files are
   collected into the installer's `licenses/` directory by the packaging
   script (implemented alongside Phase 28).
