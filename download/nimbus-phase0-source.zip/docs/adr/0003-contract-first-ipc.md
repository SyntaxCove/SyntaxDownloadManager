# ADR-0003 — Contract-first IPC with zod ⇄ serde mirror + fixture parity

**Status:** Accepted · **Date:** 2026-09-29

## Context

Three runtimes exchange data across security boundaries. Hand-rolled
"trust me" payloads are how renderers get escalated and how corrupted
downloads happen.

## Decision

- `packages/contracts` (zod) is the single source of truth for every
  cross-boundary payload and event; `CONTRACTS_VERSION` gates wire changes.
- The Rust core mirrors shapes with serde (`rename_all = "camelCase"`).
- `tests/fixtures/health.check.*.json` are shared artifacts: the Rust test
  asserts its serialized output matches the fixture; the TS test asserts the
  fixture validates against the zod schemas. Drift fails CI on both sides.
- Validation is mandatory at every hop: renderer→main (zod), main→core
  (serde + envelope checks), core→main (response narrowing), main→renderer
  (zod-validated events).

## Consequences

- Slight duplication (TS + Rust definitions) accepted deliberately; the
  fixture parity test is the tripwire. Codegen from zod → Rust is a possible
  later optimization, not a Phase 0 dependency.
- Unknown IPC methods are rejected by the router; capability growth is an
  explicit code change, never a renderer trick.
