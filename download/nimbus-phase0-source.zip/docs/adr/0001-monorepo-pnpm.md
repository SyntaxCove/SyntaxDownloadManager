# ADR-0001 — Monorepo with pnpm workspaces

**Status:** Accepted · **Date:** 2026-09-29

## Context

The product spans TypeScript (Electron main/preload/renderer, contracts) and
Rust (download-core), with strict domain boundaries. Toolchain inspected:
Node 24.21, pnpm 12.6 (via npm -g; corepack shims unavailable in the build
sandbox), Rust 1.98 (rustup, minimal profile).

## Decision

- pnpm workspaces monorepo: `apps/desktop`, `packages/*` (contracts, shared,
  config), `native/` Cargo workspace, root-level scripts/tests/docs.
- `pnpm-workspace.yaml` is the settings home (pnpm ≥ 12 ignores the
  `pnpm` field in package.json): `onlyBuiltDependencies: [electron, esbuild]`,
  `ignoredBuiltDependencies: [electron-winstaller]` (Squirrel target unused),
  `minimumReleaseAge: 1440` (supply-chain soak time; lockfile pins the
  resolved set).

## Consequences

- Workspace packages are consumed as TypeScript source (`main: src/index.ts`);
  esbuild/Vite/Node type-stripping compile them; no build step needed there.
- pnpm's strict `node_modules` forces explicit dependency declarations at
  every consumer — enforced by design, catches phantom deps.
- Electron binaries download via postinstall (allowed for `electron` only).
