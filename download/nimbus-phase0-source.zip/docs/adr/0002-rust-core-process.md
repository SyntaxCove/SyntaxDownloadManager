# ADR-0002 — Process architecture: supervised Rust core child process

**Status:** Accepted · **Date:** 2026-09-29

## Context

Downloads must survive Electron crashes, keep multi-GB transfers running off
the UI thread, and later spawn yt-dlp/FFmpeg. N-API modules would couple
lifetimes and crash the whole app.

## Decision

`download-core` is a separate executable (Rust + Tokio), launched and
supervised by Electron main with `--data-dir` and `--log-level`. Communication
is JSONL JSON-RPC 2.0 over stdio. Supervision: exponential-backoff restart
(500 ms → 8 s), intentional stops never restart, stdin EOF exits the core
(no orphans), pending RPCs rejected with typed errors.

## Consequences

- Electron crash cannot corrupt core-managed state; core crash cannot take
  the UI down (renderer shows `crashed`/`backoff`).
- stdout of the core is reserved for RPC; logs go to stderr only.
- Serialization overhead is negligible (control plane only; byte data flows
  directly to disk inside the core).
- Windows: binary is `download-core.exe`, bundled under `resources/bin/`.
