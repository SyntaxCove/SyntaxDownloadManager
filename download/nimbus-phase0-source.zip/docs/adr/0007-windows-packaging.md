# ADR-0007 — Windows packaging: electron-builder NSIS x64

**Status:** Accepted · **Date:** 2026-09-29

## Context

The first-release target is Windows 11 x64 only. The installer must be a
single artifact carrying Chromium (via Electron), the React renderer, the
Rust core, and all bundled tools.

## Decision

- electron-builder 26 with NSIS target (assisted installer: choose install
  dir, per-user), artifact `Nimbus-Setup-<version>.exe`.
- App sources packaged: `dist/**` (bundled main.js/preload.js + renderer) in
  an asar archive; `resources/bin/**` attached via `extraResources` so
  binaries stay outside asar (executables must run from disk).
- `scripts/dist.mjs` is the one-command pipeline: desktop build → cargo
  release build → stage core binary into `resources/bin/download-core/` →
  resources verify → electron-builder.
- CI: linux job runs the full test matrix (headless smoke via xvfb);
  windows job runs `pnpm dist` and uploads the installer artifact.

## Consequences

- The Linux sandbox cannot produce or visually test the Windows installer;
  it validates everything except the final NSIS step (documented risk).
- Code signing is intentionally deferred (Phase 0); adding a certificate is
  an electron-builder config change, not an architecture change.
