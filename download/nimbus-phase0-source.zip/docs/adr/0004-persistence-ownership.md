# ADR-0004 — Persistence ownership: SQLite belongs to the Rust core

**Status:** Accepted · **Date:** 2026-09-29

## Context

Electron and Rust both need state. Two writers on one database invite
locking bugs, double migrations, and split-brain corruption.

## Decision

- `nimbus.db` (SQLite, WAL, `synchronous=NORMAL`, foreign keys ON) is owned
  exclusively by `download-core`. Electron never opens it; it queries the
  core over RPC.
- Electron main owns only a small `config.json` (log level, later UI
  preferences) in the data dir.
- Schema evolves through ordered migrations recorded in `schema_migrations`;
  migration 0001 ships in Phase 0 (`app_meta`). Migrations are append-only —
  shipped ones are never edited; destructive changes require a compatibility
  migration.
- Typed relational tables per domain (downloads, segments, sources,
  recovery attempts, media jobs, …) — no generic key-value dump.

## Consequences

- One transactional writer ⇒ crash consistency is achievable (Phase 22
  startup reconciliation: DB ⇄ filesystem ⇄ segment map).
- Browser-side data (history/bookmarks, Phase 2) lives in separate Electron-
  owned stores (Chromium profile + its own tables) and never touches
  `nimbus.db`.
