# ADR-0005 — Rust core stack: Tokio + serde + rusqlite(bundled) + tracing

**Status:** Accepted · **Date:** 2026-09-29

## Context

The core needs async I/O with real concurrency, a durable embedded database
with zero user setup, and structured logging. Toolchain at Phase 0:
Rust 1.98.1 stable.

## Decision

- **Tokio** (rt-multi-thread, macros, io, signal, time, fs) — the de facto
  standard async runtime; needed for the stdio RPC loop and, later, segment
  connection pools.
- **serde/serde_json** — mirrors the zod contracts; JSONL via stdio.
- **rusqlite with `bundled` feature** — compiles SQLite into the binary: no
  system dependency, deterministic behavior on Windows, WAL supported.
  (SQLx reconsidered only if async DB access across many connections ever
  becomes real — unlikely for a single-owner writer.)
- **tracing/tracing-subscriber** — level + env filter, stderr writer only.
- **thiserror** for typed error enums; **chrono** for RFC 3339 timestamps.

## Consequences

- `cargo build --release` produces a self-contained `download-core(.exe)`;
  the Windows installer carries it under `resources/bin/download-core/`.
- First build compiles SQLite C sources (slow once, cached afterwards).
- Versions are pinned in `Cargo.toml` (semver ranges) and locked exactly in
  `Cargo.lock` committed at packaging time.
