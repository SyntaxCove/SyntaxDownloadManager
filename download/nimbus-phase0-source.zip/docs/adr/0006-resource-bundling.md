# ADR-0006 — Bundling strategy: manifest + fetch + sha256 locks

**Status:** Accepted · **Date:** 2026-09-29

## Context

Users must never install Python, Node, Deno, yt-dlp, FFmpeg, or a torrent
client. The installer must carry every helper, and updates to extractors
must be possible without rebuilding the app architecture.

## Decision

- `resources/manifest.json` declares each component: id, role, license,
  homepage, and per-platform file entries (URL, archive type, files to
  extract). `download-core` is `managed: source` (built from this repo);
  yt-dlp, Deno, FFmpeg/FFprobe are `managed: fetch`.
- `scripts/fetch-resources.mjs` downloads (argument-array subprocesses only,
  no shell), extracts zip via `unzip`/`tar`, and records
  `resources/locks/<id>.lock.json` with per-file sha256 + size + source URL +
  fetch timestamp. First fetch pins "latest" versions.
- `--verify-only` mode recomputes checksums offline; `scripts/dist.mjs`
  refuses to package if verification fails.
- Licenses are recorded per component in `docs/licenses/`; redistribution
  requirements (e.g. FFmpeg GPL build) must be audited before shipping.

## Consequences

- Reproducible, verifiable bundling; a corrupt/missing component fails the
  build instead of shipping.
- Extractor updates = re-run fetch (new pin) + package; the extractor
  adapter layer (Phase 7) isolates the change.
- Linux build sandbox can verify policy but Windows binaries are fetched on
  Windows/CI (documented limitation in the Phase 0 risk report).
