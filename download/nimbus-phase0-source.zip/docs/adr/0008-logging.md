# ADR-0008 — Logging & observability baseline

**Status:** Accepted · **Date:** 2026-09-29

## Context

Diagnostics matter for a download manager (users will hit flaky servers,
expired URLs, proxy issues), but logs must never leak credentials.

## Decision

- Structured JSONL records: `{ts, level, domain, msg, data?}`.
- Domains: app, download, recovery, media, proxy, torrent, database, ipc,
  packaging, browser. Levels: trace…error, threshold from config.
- Redaction: `redactSensitive()` strips tokens/passwords/Authorization in
  strings and serialized data before any sink; applied in the main logger.
- Sinks: main → `userData/logs/main-YYYY-MM-DD.log` (+ console in dev/smoke);
  core → stderr (captured & prefixed by main; **stdout is RPC-only**).
- A future diagnostic export (Phase 30) builds on these files and must ship
  redacted, shareable output.

## Consequences

- Log files are line-oriented and greppable by domain/level.
- The core↔main channel can never be polluted by log output by construction.
