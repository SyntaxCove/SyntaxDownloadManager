# Phase 0 — Dependency Report

**Date:** 2026-09-29 · Versions resolved from the live npm registry (not from
memory, per master prompt §4) and pinned exactly.

## Runtime-relevant versions

| Package                    | Pinned          | Notes                                                           |
| -------------------------- | --------------- | --------------------------------------------------------------- |
| Electron                   | 44.4.5          | latest stable; `WebContentsView` available (≥30) for Phase 2    |
| React / React DOM          | 19.3.0          | renderer                                                        |
| Vite                       | 8.3.1           | renderer build                                                  |
| esbuild                    | 0.28.2          | main/preload bundling (CJS for sandboxed preload compat)        |
| TypeScript                 | 5.9.3           | latest 5.x; TS 7.0.2 exists but was deferred (ecosystem compat) |
| Zod                        | 4.6.5           | contract validation                                             |
| Zustand                    | 5.0.15          | renderer state (domain stores)                                  |
| electron-builder           | 26.15.3         | NSIS x64 packaging                                              |
| vitest                     | 5.0.2           | contract tests                                                  |
| eslint + typescript-eslint | 9.39.5 + 8.70.1 | 8.71.0 excluded by `minimumReleaseAge` (published same day)     |
| prettier                   | 3.9.9           | formatting                                                      |

## Rust crate pins

| Crate                        | Version                                                        | Why                                       |
| ---------------------------- | -------------------------------------------------------------- | ----------------------------------------- |
| tokio                        | 1.45 (features: rt-multi-thread, macros, io, signal, time, fs) | async runtime                             |
| serde / serde_json           | 1.0 / 1.0.151 (resolved)                                       | contract mirror + JSONL                   |
| rusqlite                     | 0.32.1 `bundled`                                               | SQLite compiled in — no system dependency |
| tracing / tracing-subscriber | 0.1 / 0.3 (env-filter)                                         | structured logs                           |
| thiserror                    | 2.0                                                            | typed errors                              |
| chrono                       | 0.4 (clock)                                                    | RFC 3339 timestamps                       |

## Supply-chain policy

- `minimumReleaseAge: 1440` (1 day soak) enforced by pnpm 12; the first
  resolution attempt rejected same-day releases (typescript-eslint 8.71.0)
  and was re-pinned to 8.70.1 — the policy worked as intended.
- Exact versions in `package.json` + committed `pnpm-lock.yaml`; CI installs
  with `--frozen-lockfile`.
- Build scripts are explicitly allow-listed (`onlyBuiltDependencies`:
  electron, esbuild); `electron-winstaller` is deliberately ignored (Squirrel
  path unused).
- `Cargo.lock` is committed at packaging time for byte-exact Rust builds.

## Bundled external components (fetched at packaging time)

| Component                   | License                     | Source                                                       |
| --------------------------- | --------------------------- | ------------------------------------------------------------ |
| yt-dlp                      | Unlicense                   | github.com/yt-dlp/yt-dlp (latest, pinned into lock at fetch) |
| Deno                        | MIT                         | github.com/denoland/deno (latest, pinned)                    |
| FFmpeg/FFprobe (essentials) | GPL-3.0-or-later components | gyan.dev release build (pinned)                              |

Checksums: sha256 locks are written on fetch (`resources/locks/`) and
verified offline before any packaging (`pnpm resources:verify`).
