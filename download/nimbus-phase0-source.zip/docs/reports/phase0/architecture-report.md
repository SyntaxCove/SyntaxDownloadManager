# Phase 0 — Architecture Report

**Scope:** discovery & foundation (master prompt §10) · **Date:** 2026-09-29

## What was established

| Area               | Outcome                                                                                                                                               |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Package manager    | pnpm 12.6 workspaces; settings in `pnpm-workspace.yaml` (pnpm ≥12 ignores the package.json `pnpm` field)                                              |
| TypeScript         | 5.9.3 strict, project-local tsconfigs extending `packages/config/tsconfig.base.json`; TS 7 deliberately deferred (ADR-0001 ecosystem-compat note)     |
| Rust workspace     | `native/Cargo.toml` → member `download-core` (lib + bin); Rust 1.98.1 stable                                                                          |
| Electron structure | main (`electron/main`) · preload (`electron/preload`, sandboxed) · renderer (React 19 + Vite 8); bundles: esbuild → `dist/main.js`, `dist/preload.js` |
| Renderer           | React 19.3, Zustand 5, strict CSP (dev-only relaxation for the Vite React preamble), Windows 11 dark visual baseline                                  |
| IPC protocol       | JSONL JSON-RPC 2.0 over stdio (main⇄core) + whitelisted `nimbus:rpc` channel (renderer⇄main); zod ⇄ serde contract mirror; `CONTRACTS_VERSION = 1`    |
| Logging            | Structured JSONL, 10 domains, redaction before sink; core stdout reserved for RPC                                                                     |
| Configuration      | `config.json` owned by main (log level); DB owned by core (ADR-0004)                                                                                  |
| SQLite ownership   | rusqlite `bundled`, WAL, ordered migrations in `schema_migrations`, migration `0001_core_meta` applied                                                |
| Dependency policy  | pinned exact versions, `minimumReleaseAge: 1440`, build scripts allow-listed explicitly                                                               |
| Resource bundling  | `resources/manifest.json` + fetch/verify with sha256 locks (ADR-0006)                                                                                 |
| Windows packaging  | electron-builder 26 NSIS x64 config + `scripts/dist.mjs` pipeline (ADR-0007)                                                                          |
| Testing            | vitest (contracts) · cargo test (core) · JSONL integration test · headless xvfb smoke test · GitHub Actions CI (linux matrix + windows packaging)     |

## Acceptance criteria — verification results

| Criterion (§10)                      | Status             | Evidence                                                                                            |
| ------------------------------------ | ------------------ | --------------------------------------------------------------------------------------------------- |
| Application starts                   | **PASS**           | smoke run logs (`main.js` bootstrap)                                                                |
| Electron window opens                | **PASS**           | headless X11 run (Xvfb), `ready-to-show` → show                                                     |
| React renderer loads                 | **PASS**           | `did-finish-load` reached; renderer build 310 kB js / 3.2 kB css                                    |
| Rust core starts as supervised child | **PASS**           | `core process spawned pid=7317` → `state running`                                                   |
| Typed health-check exchange          | **PASS**           | `core.health` verified over JSONL (integration) and in-process (smoke)                              |
| SQLite database initializes          | **PASS**           | `migration applied version=1`, `journal=wal`                                                        |
| Logging works                        | **PASS**           | JSONL records emitted in smoke output, file sink attached                                           |
| Development build works              | **PASS**           | `pnpm dev` orchestration (vite + esbuild watch + electron)                                          |
| Production build can be generated    | **PASS** (bundles) | `dist/renderer` + `dist/main.js`/`preload.js`; final NSIS `.exe` requires Windows (see risk report) |

## Test summary (this sandbox run)

- `pnpm typecheck` — 3/3 projects clean
- `pnpm lint` — clean
- `pnpm test:contracts` — **10/10**
- `pnpm core:test` — **4/4** (incl. TS⇄Rust fixture parity)
- `pnpm test:integration` — **7/7 checks PASS** against the real release binary
- `pnpm smoke` — **SMOKE_OK core=0.1.0 db.schemaVersion=1 journal=wal**
- `pnpm resources:verify` — policy behaves correctly (skips non-target platform, enforces locks)

## Repository state

AGENTS.md, README.md, 5 architecture docs, 8 ADRs, 3 discovery reports,
licenses doc, CI workflow, resource manifest — all present under version
control as the initial Phase 0 commit.

## What remains (next phases)

Phase 1 (Windows 11 shell: titlebar, navigation, theme system, shortcuts) →
Phase 2 (embedded browser via `WebContentsView`) → Phase 3/4 (download
engine, segments) → Phase 5 (recovery engine) → … → Phase 31. The roadmap and
per-phase acceptance criteria are defined by the master build prompt; each
phase follows the AGENTS.md workflow.
