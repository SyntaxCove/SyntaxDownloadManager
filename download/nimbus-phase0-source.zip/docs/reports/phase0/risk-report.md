# Phase 0 — Risk Report

**Date:** 2026-09-29 · Owners: implementation agent + human director

## R1 — Build environment is Linux, not Windows 11 (HIGH, accepted)

The implementation sandbox is a headless Linux box. Everything except the
final Windows-only steps is verified here (Electron actually ran under Xvfb;
the Rust core was built and exercised). The NSIS installer itself cannot be
produced or visually tested here.

- **Mitigation:** `scripts/dist.mjs` + CI `dist-windows` job run the exact
  packaging pipeline on `windows-latest` and upload the artifact; local
  Windows build is one command (`pnpm dist`).
- **Residual:** visual/manual QA of the real installer + window chrome must
  happen on Windows hardware.

## R2 — Extractor fragility (yt-dlp / YouTube) (HIGH, structural)

Site breakage is expected over time; YouTube is an adversarial moving target.

- **Mitigation:** extraction is centralized behind `YtDlpExtractorAdapter`
  (Phase 7/8); the extractor stack (yt-dlp + Deno/EJS) is versioned,
  checksum-locked, and updatable without rebuilding the app; a generic
  fallback path stays available; diagnostics report extractor versions.

## R3 — Supply-chain integrity of bundled binaries (MEDIUM)

- **Mitigation:** sha256 locks, `minimumReleaseAge`, frozen lockfiles,
  allow-listed build scripts, license audit before shipping
  (`docs/licenses/`). Unknown-license components are never added silently.

## R4 — pnpm 12 policy shifts (LOW, observed once)

pnpm 12 ignores the package.json `pnpm` field and hard-fails on unapproved
build scripts / too-fresh releases. Already handled (settings migrated to
`pnpm-workspace.yaml`; typescript-eslint re-pinned). CI uses frozen lockfiles
so resolution drift cannot recur.

## R5 — Renderer/IPC regression risk as features grow (MEDIUM)

- **Mitigation:** contract-first IPC (ADR-0003) with fixture parity enforced
  on both TS and Rust sides; router reject-by-default; strict CSP; sandboxed
  preload; security review step in every phase workflow (AGENTS.md).

## R6 — Data corruption across crashes (MEDIUM, by design later)

Full crash-consistency (startup reconciliation, journaling) lands in Phase 22. Until then, WAL + migration transactions + atomic finalize rules already
reduce the blast radius; interim phases must not finalize files without
validation.

## R7 — Performance envelope (LOW for Phase 0)

20+ downloads, many tabs, hashing, muxing: all heavy work is in the Rust
core or bundled tools; progress pushes are batched by design (§48). Risks
re-visit at Phases 4 and 23 with measurable budgets.

## R8 — Single-platform focus (accepted)

Windows 11 x64 is the only first-release target (master prompt §3). The Rust
core and renderer remain portable; Electron main uses platform-agnostic APIs
plus explicit `process.platform` branches where needed (binary naming,
signals).
