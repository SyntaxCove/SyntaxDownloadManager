# Download Engine — Architecture (design for Phases 3–4, 14, 21–22)

Phase 0 ships the engine's skeleton (process, RPC, storage). This document
fixes the design the later phases implement.

## Requirements recap

- Single- and multi-connection HTTP/HTTPS with `Range`
- Pause / resume / retry / cancel / queue
- Progress, speed, ETA, size, destination, error classification
- Temporary files (`<name>.partial`) + atomic finalize
- Configurable per-download and global concurrency and bandwidth limits,
  with adaptive reduction under server throttling
- Durable per-segment state that survives crashes

## Layering (inside download-core)

```
api/          RPC method handlers (download.create/start/pause/…)
downloader/   Job orchestration, state machine
segments/     SegmentScheduler, RangePlanner, ConnectionPool
recovery/     Failure classification, URL rebinding (see recovery.md)
storage/      SQLite repositories + migrations (owner of all task state)
proxy/        Per-job proxy selection
media/        Extractor adapters + mux coordination (phases 7–10)
torrent/      Adapter around a Rust torrent library (phase 14)
scheduler/    Durable scheduler (phase 15)
```

## State machine (single source of truth in `downloader/`)

`QUEUED → PREPARING → STARTING → DOWNLOADING → (PAUSED|RETRYING|RECOVERING|
VALIDATING) → FINALIZING → COMPLETED`, with `FAILED` / `CANCELLED` / `REMOVED`
terminal states. Invalid transitions are rejected programmatically; every
transition is persisted before side effects continue.

## Segments

- Ranges planned by `RangePlanner` (respecting server `Accept-Ranges`,
  size, and target connection count).
- Each segment has durable state: `{index, start, end, downloaded, etag,
status}` in SQLite — completed segments are never re-fetched after a
  restart or URL rebinding.
- `SegmentScheduler` adapts concurrency: slow/failing segments shrink the
  pool; healthy servers grow it (bounded by user limits).
- Retries use classified backoff; a failed segment never destroys siblings.

## Durability rules

1. Never write into the final filename; `file.ext.partial` only.
2. Flush completed segment ranges before acknowledging bytes to the
   scheduler; state journal precedes data commitment.
3. Finalize = verify (size/hash where available) → fsync → atomic rename.
4. Startup reconciliation (Phase 22): DB ⇄ filesystem ⇄ segment map are
   compared and repaired; "state says complete but file missing" is treated
   as corruption, never as success.

## Integrity

SHA-1/SHA-256 (extensible), streaming and asynchronous; whole-file hashes are
computed once and cached by (size, etag, path, mtime) to avoid redundant
hashing of huge files.

## Performance

20+ concurrent downloads must keep the UI at 60 fps: Rust performs all file
and network I/O; progress is aggregated and pushed at a bounded rate; the
renderer normalizes state and memoizes rows.
