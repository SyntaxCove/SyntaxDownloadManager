# System Architecture

## Overview

Nimbus is a desktop application that unifies a Chromium browser and a
resilient download manager. Its architecture treats each of the following as
first-class subsystems with explicit boundaries:

| Subsystem                        | Owner           | Technology                        |
| -------------------------------- | --------------- | --------------------------------- |
| Desktop shell & browser          | Electron main   | Electron, `WebContentsView`       |
| UI                               | Renderer        | React 19 + Vite + Zustand         |
| Typed IPC boundary               | Contracts       | zod (TS) ⇄ serde (Rust)           |
| Download/Recovery/Storage engine | Rust core       | Tokio, rusqlite (SQLite WAL)      |
| Media extraction                 | Extractor layer | yt-dlp + Deno (bundled)           |
| Media processing                 | Mux/inspection  | FFmpeg/FFprobe (bundled)          |
| Torrent                          | Adapter         | Rust-native library (later phase) |

## Non-negotiable properties

1. **Durability** — all task state lives in SQLite owned by the Rust core;
   partial data is never destroyed on failure; files are finalized atomically.
2. **Recoverability** — URL identity ≠ file identity; a failed download is
   rebound to a freshly acquired, validated source and resumes from existing
   ranges.
3. **Security** — remote pages are sandboxed without Node access; the
   renderer speaks only validated RPC; bundled tools are spawned with explicit
   paths and argument arrays.
4. **No helper installations** — yt-dlp, Deno, FFmpeg, and the core ship
   inside the installer, checksum-pinned via `resources/manifest.json`.

## Process model

Three runtimes cooperate (see `processes.md`):

```
React renderer  ──typed IPC──▶  Electron main  ──JSONL JSON-RPC──▶  download-core (Rust)
                                                                     ├── yt-dlp / Deno
                                                                     └── FFmpeg / FFprobe
```

- The renderer never touches the filesystem, network stack, or native tools.
- Electron main owns windows, sessions, proxies (browser side), and the
  lifecycle of the core process; it supervises and restarts it.
- The Rust core owns the database, download execution, recovery, and the
  spawning of extractor/processing tools.

## Data ownership

| Store                     | Owner         | Content                                                                                          |
| ------------------------- | ------------- | ------------------------------------------------------------------------------------------------ |
| `config.json`             | Electron main | small app config (log level, …)                                                                  |
| `nimbus.db` (SQLite, WAL) | Rust core     | downloads, segments, sources, recovery journal, media jobs, … (phases add tables via migrations) |
| `resources/locks/`        | build scripts | sha256 pins of bundled components                                                                |

Domains never write into each other's stores.

## Failure posture

- Core crash → detected by supervision, exponential-backoff restart, pending
  RPCs rejected with typed errors, UI shows state; on-disk state is unaffected.
- App crash / power loss → startup reconciliation (Phase 22) compares
  database ⇄ filesystem ⇄ segment maps and repairs inconsistencies.
- Expired URLs → Recovery Engine (see `recovery.md`).
