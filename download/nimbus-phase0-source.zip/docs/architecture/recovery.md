# Recovery Engine — Architecture (design for Phases 5, 20; HLS/DASH in Ph 10)

The Recovery Engine is Nimbus's differentiator. Principle:

> **URL expired ≠ download lost.**

## Flow

```
Download failure
        │
        ▼
Classify error (typed codes, recoverability in packages/shared)
        │
        ├── transient ──▶ retry (exponential backoff, bounded)
        │
        └── likely source expiration (403/404/410, expired token, redirect change…)
                ↓
         attempt source refresh
                ↓
   extractor reacquisition OR browser-assisted reacquisition
                ↓
           new candidate URL
                ↓
        probe (small Range request)
                ↓
      validate resource identity
                │
           ┌────┴────┐
         valid     invalid
           ▼           ▼
        rebind       stop (keep partial data, surface to user)
           │
           ▼
   resume missing ranges only
```

## Stored recovery context (per download)

original URL · current URL · source page URL · source type · extractor used ·
filename · content type · expected size · ETag · Last-Modified ·
Accept-Ranges · headers · cookies/session reference · proxy profile ·
segment map · downloaded ranges.

## Identity validation (never blindly append)

Before rebinding, compare as many signals as available: Content-Length,
Content-Type, ETag, Last-Modified, Content-Range, filename, extractor
metadata — then a small `Range: bytes=<known-offset>-<known-offset+probe>`
probe to verify the server serves the expected bytes at the expected offset.
Same size but different resource ⇒ **DOWNLOAD_WRONG_RESOURCE** (fatal, data
preserved, user informed). A new URL is appended to nothing.

## Browser-assisted recovery

The user opens/refreshes the original page in the integrated browser; the
Media/Download detectors observe the newly issued request; the app presents
matching candidates; the user (or auto-recovery, when confident) selects one;
validation runs; the URL is rebound; the download continues from the
completed ranges. Manual "Replace URL" shares the same validation path.

## HLS/DASH specifics

Segment-level progress is independent of the playlist URL. If a manifest
expires: reacquire the playlist, identify the same representation (by
init/segment URL patterns, resolution, codecs, bandwidth), map existing
segments onto the new manifest, and fetch only missing segments. 720/800
complete segments stay complete.

## Recovery journal

Every attempt is persisted (`download_recovery_attempts`): timestamp, reason,
old/new URL hash, old/new metadata snapshot, validation result, action taken.
Logs never contain un-redacted sensitive URLs (master prompt §41).

## Anti-patterns (forbidden)

- Retrying a fundamentally invalid resource forever
- Deleting partial data on failure without explicit user instruction
- Trusting URL equality as file identity
- Silent auto-recovery without journal entries
