# Process Architecture

## Topology

```
┌─────────────────────────────┐
│       React Renderer        │
│  Browser UI / Download UI   │
│  Settings / Media selection │
└──────────────┬──────────────┘
               │ typed IPC (contextBridge, whitelisted channel)
┌──────────────▼──────────────┐
│       Electron Main         │
│  Window Manager             │
│  Browser Manager (Phase 2)  │
│  Session Manager (Phase 2)  │
│  Proxy Manager (Phase 13)   │
│  Media Detector (Phase 6)   │
│  Extractor Coordinator (Ph7)│
│  Download Coordinator       │
│  CoreProcessManager  ◀──────│── supervision/restart/backoff
└──────────────┬──────────────┘
               │ JSONL JSON-RPC 2.0 over stdio
┌──────────────▼──────────────┐
│        download-core        │
│  Download Engine            │
│  Recovery Engine            │
│  Storage Engine (SQLite)    │
│  Torrent Adapter            │
│  Integrity Engine           │
│  Scheduler                  │
└──────┬───────────────┬──────┘
       │               │
 yt-dlp / EJS / Deno   FFmpeg / FFprobe
 (bundled, spawned with
  explicit paths + argv)
```

## Lifecycle (implemented in Phase 0)

1. Electron main starts, loads config, initializes the structured logger.
2. `CoreProcessManager` spawns `download-core --data-dir <dir> --log-level <level>`.
3. Main performs `core.health`; the result is validated against the contract
   and cached. State transitions are pushed to the renderer (`core:status`).
4. The renderer loads (strict CSP) and calls `app.info` / `core.health`
   through the preload bridge.
5. On quit, main stops the core gracefully (SIGTERM/kill, 3 s force timeout).

## Supervision rules

- Intentional stops never trigger restarts.
- Crashes restart with exponential backoff (500 ms → 8 s cap), tracked and
  surfaced in `CoreStatusEvent.restarts`; the counter resets on a healthy
  health check.
- stdin EOF (parent death) makes the core exit by itself — no orphan cores.
- Pending RPCs are rejected with typed errors on exit/timeout (10 s default).

## Tool spawning (Phases 7–9, designed now)

Every external tool (yt-dlp, deno, ffmpeg, ffprobe) is:

- resolved from `resources/bin/<component>/` (checksum-locked at fetch time),
- spawned with an explicit executable path and argument array,
- run with stdout parsed as data, stderr treated as logs,
- killed deterministically on job cancel/shutdown.
