# IPC Architecture

## Principles

1. **No arbitrary commands.** The renderer can only call the single
   whitelisted channel `nimbus:rpc` with a `{method, params}` payload.
2. **Validated at every hop.** Zod validates renderer→main and main→renderer
   payloads; serde + explicit checks validate main→core and core→main.
   A malformed request is rejected with a typed error — never trusted.
3. **One contract source of truth.** `packages/contracts` (zod) defines every
   payload; the Rust core mirrors the shapes with serde. Shared fixtures in
   `tests/fixtures/` are asserted by both TS and Rust tests (fixture parity).
4. **Versioned.** `CONTRACTS_VERSION` is an integer both sides agree on;
   non-additive changes bump it and update the mirror + fixtures.

## Wire format

JSON-RPC 2.0 over JSONL (one message per line, `\n`-delimited):

```json
→ {"jsonrpc":"2.0","id":1,"method":"core.health","params":{}}
← {"jsonrpc":"2.0","id":1,"result":{"status":"ok","name":"download-core", …}}
← {"jsonrpc":"2.0","id":1,"error":{"code":-32601,"message":"method not found: x.y"}}
```

Reserved codes: `-32700` parse, `-32600` invalid request, `-32601` method not
found, `-32602` invalid params, `-32603` internal; Nimbus adds `-32000`
CORE_FAILURE, `-32001` VALIDATION, `-32002` UNAVAILABLE.

## Method namespaces

| Namespace    | Handler         | Phase 0 methods                             |
| ------------ | --------------- | ------------------------------------------- |
| `app.*`      | Electron main   | `app.info`                                  |
| `config.*`   | Electron main   | `config.get`                                |
| `core.*`     | Rust core       | `core.health`, `core.ping`, `core.shutdown` |
| `download.*` | core (via main) | Phase 3+                                    |
| `media.*`    | extractor layer | Phase 7+                                    |
| `browser.*`  | Electron main   | Phase 2+                                    |
| `proxy.*`    | main/core split | Phase 13+                                   |

The router rejects any method outside the registered set — the renderer
cannot expand its capabilities by guessing names.

## Streaming events

High-frequency state changes use push channels, throttled at the source:

| Channel             | Direction              | Payload contract                   | Phase    |
| ------------------- | ---------------------- | ---------------------------------- | -------- |
| `core:status`       | main → renderer        | `CoreStatusEvent`                  | 0 (live) |
| `download.progress` | core → main → renderer | (planned, batched ≤ ~4 Hz per job) | 3+       |
| `media.discovery`   | main → renderer        | (planned)                          | 6+       |

Rules: progress events are batched, rows are memoized, and per-byte updates
never reach React state (performance requirement §48).

## Preload bridge

`sandbox: true` + `contextIsolation: true`. The bridge exposes exactly:

```ts
rpc(method, params?)            // → JSON-RPC envelope (validated)
onCoreStatus(listener) → unsub  // validated CoreStatusEvent
```

No filesystem, no shell, no events beyond the registered list.
