import { spawnSync } from 'node:child_process';
import { copyFileSync, existsSync, mkdirSync } from 'node:fs';
import { join, resolve } from 'node:path';
import process from 'node:process';

// Full Windows packaging pipeline (one command on a Windows machine):
//   1. build renderer + electron bundles
//   2. build download-core (release)
//   3. copy download-core into resources/bin/download-core/
//   4. verify bundled resources (yt-dlp/ffmpeg/deno) are present and verified
//   5. run electron-builder (NSIS, x64)
//
// Prerequisite: run `pnpm resources:fetch` once so resources/bin is populated.

const ROOT = resolve(import.meta.dirname, '..');
const step = (name) => console.log(`\n=== ${name} ===`);

function run(cmd, args, opts = {}) {
  const result = spawnSync(cmd, args, {
    stdio: 'inherit',
    shell: process.platform === 'win32',
    ...opts,
  });
  if (result.status !== 0) {
    console.error(`step failed: ${cmd} ${args.join(' ')}`);
    process.exit(result.status ?? 1);
  }
}

step('1/5 desktop build');
run('pnpm', ['-C', 'apps/desktop', 'build']);

step('2/5 rust core build (release)');
run('cargo', ['build', '--release', '--manifest-path', join(ROOT, 'native', 'Cargo.toml')]);

step('3/5 stage download-core into resources/bin');
const coreBinary = join(
  ROOT,
  'native',
  'target',
  'release',
  process.platform === 'win32' ? 'download-core.exe' : 'download-core',
);
if (!existsSync(coreBinary)) {
  console.error(`core binary missing: ${coreBinary}`);
  process.exit(1);
}
const staging = join(ROOT, 'resources', 'bin', 'download-core');
mkdirSync(staging, { recursive: true });
copyFileSync(
  coreBinary,
  join(staging, process.platform === 'win32' ? 'download-core.exe' : 'download-core'),
);

step('4/5 verify bundled resources');
const verify = spawnSync('node', [join(ROOT, 'scripts', 'fetch-resources.mjs'), '--verify-only'], {
  stdio: 'inherit',
  encoding: 'utf8',
});
if (verify.status !== 0) {
  console.error('bundled resources missing or unverified — run "pnpm resources:fetch" first');
  process.exit(verify.status ?? 1);
}

step('5/5 electron-builder (win nsis x64)');
run(
  'pnpm',
  ['exec', 'electron-builder', '--config', 'electron-builder.yml', '--win', 'nsis', '--x64'],
  {
    cwd: join(ROOT, 'apps', 'desktop'),
  },
);
console.log('\nDone. Installer: apps/desktop/dist/installer/');
