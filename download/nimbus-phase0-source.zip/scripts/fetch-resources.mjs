import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import {
  createReadStream,
  createWriteStream,
  existsSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { join, resolve } from 'node:path';
import process from 'node:process';

// Fetches and verifies bundled runtime components declared in
// resources/manifest.json. First run downloads + extracts + records a lock
// file with sha256 checksums; later runs verify against the lock.
//   pnpm resources:fetch          download/refresh + verify
//   pnpm resources:verify         verify only (no network)
//
// No shell interpolation is used anywhere; every spawned command uses
// argument arrays (master prompt §57).

const ROOT = resolve(import.meta.dirname, '..');
const BIN_ROOT = join(ROOT, 'resources', 'bin');
const LOCK_ROOT = join(ROOT, 'resources', 'locks');
const verifyOnly = process.argv.includes('--verify-only');

const PLATFORM_MAP = {
  'win32-x64': 'windows-x64',
  'linux-x64': 'linux-x64',
  'linux-arm64': 'linux-arm64',
  'darwin-arm64': 'darwin-arm64',
  'darwin-x64': 'darwin-x64',
};

function sha256File(path) {
  return new Promise((resolvePromise, rejectPromise) => {
    const hash = createHash('sha256');
    const stream = createReadStream(path);
    stream.on('data', (chunk) => hash.update(chunk));
    stream.on('end', () => resolvePromise(hash.digest('hex')));
    stream.on('error', rejectPromise);
  });
}

function extractZip(zipPath, destDir) {
  const useTar = process.platform === 'win32';
  const result = useTar
    ? spawnSync('tar', ['-xf', zipPath, '-C', destDir])
    : spawnSync('unzip', ['-oq', zipPath, '-d', destDir]);
  if (result.status !== 0) {
    const tool = useTar ? 'tar' : 'unzip';
    throw new Error(`zip extraction failed (${tool})${result.stderr ? `: ${result.stderr}` : ''}`);
  }
}

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) {
      out.push(...walk(full));
    } else {
      out.push(full);
    }
  }
  return out;
}

async function downloadTo(url, destPath) {
  const response = await fetch(url, { redirect: 'follow' });
  if (!response.ok || response.body === null) {
    throw new Error(`download failed: ${url} (HTTP ${response.status})`);
  }
  await pipeline(response.body, createWriteStream(destPath));
}

const manifest = JSON.parse(readFileSync(join(ROOT, 'resources', 'manifest.json'), 'utf8'));
const target = PLATFORM_MAP[`${process.platform}-${process.arch}`];
if (!target) {
  console.error(`no resource entries for ${process.platform}-${process.arch}`);
  process.exit(1);
}

mkdirSync(LOCK_ROOT, { recursive: true });
let failures = 0;

for (const component of manifest.components) {
  if (component.managed !== 'fetch') {
    console.log(`- ${component.id}: managed in-repo (skip)`);
    continue;
  }
  const entry = component.files.find((file) => file.platform === target);
  if (!entry) {
    console.log(`- ${component.id}: no file entry for ${target} (skip)`);
    continue;
  }

  const componentDir = join(BIN_ROOT, component.id);
  const lockPath = join(LOCK_ROOT, `${component.id}.lock.json`);

  if (verifyOnly) {
    if (!existsSync(lockPath)) {
      console.error(`- ${component.id}: MISSING lock (${lockPath}) — run "pnpm resources:fetch"`);
      failures += 1;
      continue;
    }
    const lock = JSON.parse(readFileSync(lockPath, 'utf8'));
    let ok = true;
    for (const file of lock.files) {
      const path = join(componentDir, file.name);
      if (!existsSync(path)) {
        console.error(`- ${component.id}/${file.name}: missing`);
        ok = false;
      } else if ((await sha256File(path)) !== file.sha256) {
        console.error(`- ${component.id}/${file.name}: sha256 mismatch`);
        ok = false;
      }
    }
    if (ok) {
      console.log(`- ${component.id}: verified (${lock.files.length} file(s))`);
    } else {
      failures += 1;
    }
    continue;
  }

  mkdirSync(componentDir, { recursive: true });
  console.log(`- ${component.id}: downloading ${entry.url}`);
  const archivePath = join(componentDir, entry.filename);
  await downloadTo(entry.url, archivePath);

  if (entry.archive === 'zip') {
    extractZip(archivePath, componentDir);
    rmSync(archivePath, { force: true });
    const wanted = entry.extractFiles ?? [];
    const all = walk(componentDir);
    const files = [];
    for (const want of wanted) {
      const found = all.find((path) => path.split(/[\\/]/).pop() === want);
      if (found === undefined) {
        console.error(`- ${component.id}: expected file not found in archive: ${want}`);
        failures += 1;
        continue;
      }
      files.push({
        name: want,
        sha256: await sha256File(found),
        sizeBytes: statSync(found).size,
      });
    }
    writeFileSync(
      lockPath,
      `${JSON.stringify(
        {
          component: component.id,
          platform: target,
          source: entry.url,
          fetchedAt: new Date().toISOString(),
          files,
        },
        null,
        2,
      )}\n`,
    );
    console.log(`- ${component.id}: locked (${files.length} file(s))`);
  } else {
    writeFileSync(
      lockPath,
      `${JSON.stringify(
        {
          component: component.id,
          platform: target,
          source: entry.url,
          fetchedAt: new Date().toISOString(),
          files: [
            {
              name: entry.filename,
              sha256: await sha256File(archivePath),
              sizeBytes: statSync(archivePath).size,
            },
          ],
        },
        null,
        2,
      )}\n`,
    );
    console.log(`- ${component.id}: locked`);
  }
}

if (failures > 0) {
  console.error(`resources: ${failures} failure(s)`);
  process.exit(1);
}
console.log('resources: OK');
