pub mod methods;

use std::sync::Arc;

use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tokio::io::{AsyncBufReadExt, AsyncWriteExt};

use crate::storage::Storage;

pub mod codes {
    pub const PARSE: i32 = -32700;
    pub const INVALID_REQUEST: i32 = -32600;
    pub const METHOD_NOT_FOUND: i32 = -32601;
    pub const INVALID_PARAMS: i32 = -32602;
    pub const INTERNAL: i32 = -32603;
    pub const CORE_FAILURE: i32 = -32000;
    pub const VALIDATION: i32 = -32001;
}

/// Wire id: number or string, mirroring contracts JsonRpcId (ADR-0003).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum RpcId {
    Number(i64),
    Text(String),
}

#[derive(Debug, Deserialize)]
pub struct IncomingRequest {
    pub jsonrpc: String,
    #[serde(default = "default_id")]
    pub id: RpcId,
    pub method: String,
    #[serde(default)]
    pub params: Option<Value>,
}

fn default_id() -> RpcId {
    RpcId::Number(0)
}

pub fn success(id: &RpcId, result: Value) -> Value {
    json!({ "jsonrpc": "2.0", "id": id, "result": result })
}

pub fn failure(id: Option<&RpcId>, code: i32, message: String, data: Option<Value>) -> Value {
    let id_value = match id {
        Some(id) => serde_json::to_value(id).unwrap_or(Value::Null),
        None => Value::Null,
    };
    let mut error = serde_json::Map::new();
    error.insert("code".to_string(), json!(code));
    error.insert("message".to_string(), json!(message));
    if let Some(d) = data {
        error.insert("data".to_string(), d);
    }
    json!({ "jsonrpc": "2.0", "id": id_value, "error": error })
}

pub enum Action {
    Reply(Value),
    ReplyThenShutdown(Value),
}

/// Central RPC dispatcher. All method routing lives here — handlers never
/// scatter state transitions across random modules (master prompt §45).
pub fn dispatch(storage: &Arc<Storage>, req: &IncomingRequest) -> Action {
    let id = &req.id;

    match req.method.as_str() {
        "core.health" => match methods::health::handle(storage) {
            Ok(result) => Action::Reply(success(id, result)),
            Err(err) => Action::Reply(failure(
                Some(id),
                codes::CORE_FAILURE,
                format!("health check failed: {err}"),
                None,
            )),
        },
        "core.ping" => Action::Reply(success(
            id,
            json!({ "pong": true, "time": now_rfc3339() }),
        )),
        "core.shutdown" => Action::ReplyThenShutdown(success(id, json!({ "shuttingDown": true }))),
        other => Action::Reply(failure(
            Some(id),
            codes::METHOD_NOT_FOUND,
            format!("method not found: {other}"),
            None,
        )),
    }
}

pub fn now_rfc3339() -> String {
    chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true)
}

/// Reads JSONL requests from stdin and writes JSONL responses to stdout.
/// Returns the process exit code. Stdin EOF (parent died/quit) and SIGINT/
/// SIGTERM trigger a graceful shutdown.
pub async fn serve(storage: Arc<Storage>) -> i32 {
    let mut lines = tokio::io::BufReader::new(tokio::io::stdin()).lines();
    let mut out = tokio::io::stdout();

    loop {
        tokio::select! {
            line = lines.next_line() => {
                match line {
                    Ok(Some(line)) => {
                        let trimmed = line.trim();
                        if trimmed.is_empty() {
                            continue;
                        }
                        let action = match serde_json::from_str::<IncomingRequest>(trimmed) {
                            Ok(req) => {
                                if req.jsonrpc != "2.0" {
                                    Action::Reply(failure(
                                        Some(&req.id),
                                        codes::INVALID_REQUEST,
                                        format!("unsupported jsonrpc version: {}", req.jsonrpc),
                                        None,
                                    ))
                                } else {
                                    dispatch(&storage, &req)
                                }
                            }
                            Err(err) => {
                                tracing::warn!(error = %err, "unparseable rpc line");
                                Action::Reply(failure(
                                    None,
                                    codes::PARSE,
                                    format!("parse error: {err}"),
                                    None,
                                ))
                            }
                        };

                        let shutdown = matches!(action, Action::ReplyThenShutdown(_));
                        let Action::Reply(response) = action else {
                            return 0;
                        };
                        if out
                            .write_all(format!("{response}\n").as_bytes())
                            .await
                            .is_err()
                            || out.flush().await.is_err()
                        {
                            tracing::error!("stdout closed; parent is gone");
                            return 1;
                        }
                        if shutdown {
                            tracing::info!("shutdown requested via rpc");
                            return 0;
                        }
                    }
                    Ok(None) => {
                        tracing::info!("stdin closed by parent; shutting down");
                        return 0;
                    }
                    Err(err) => {
                        tracing::error!(error = %err, "stdin read error");
                        return 1;
                    }
                }
            }
            _ = shutdown_signal() => {
                tracing::info!("termination signal received; shutting down");
                return 0;
            }
        }
    }
}

async fn shutdown_signal() {
    #[cfg(unix)]
    {
        let mut term = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate())
            .expect("failed to install SIGTERM handler");
        tokio::select! {
            _ = tokio::signal::ctrl_c() => {}
            _ = term.recv() => {}
        }
    }
    #[cfg(not(unix))]
    {
        let _ = tokio::signal::ctrl_c().await;
    }
}
