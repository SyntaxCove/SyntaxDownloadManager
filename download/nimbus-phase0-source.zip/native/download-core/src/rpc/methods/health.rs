use std::sync::{Arc, OnceLock};
use std::time::Instant;

use serde::Serialize;
use serde_json::Value;

use crate::storage::Storage;

static START: OnceLock<Instant> = OnceLock::new();

pub fn mark_start() {
    let _ = START.get_or_init(Instant::now);
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CoreDbHealth {
    pub path: String,
    pub schema_version: i64,
    pub journal_mode: String,
}

/// Mirrors contracts CoreHealthResult (packages/contracts/src/methods/core.ts).
/// Field names and types MUST stay in lockstep; a fixture-parity test in
/// tests/integration.rs enforces this against tests/fixtures.
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct CoreHealth {
    pub status: String,
    pub name: String,
    pub version: String,
    pub pid: u32,
    pub uptime_ms: u64,
    pub db: CoreDbHealth,
    pub time: String,
}

pub fn handle(storage: &Arc<Storage>) -> Result<Value, String> {
    let db = storage.status().map_err(|e| e.to_string())?;
    let health = CoreHealth {
        status: "ok".to_string(),
        name: "download-core".to_string(),
        version: env!("CARGO_PKG_VERSION").to_string(),
        pid: std::process::id(),
        uptime_ms: START
            .get_or_init(Instant::now)
            .elapsed()
            .as_millis()
            .min(u64::MAX as u128) as u64,
        db: CoreDbHealth {
            path: db.path,
            schema_version: db.schema_version,
            journal_mode: db.journal_mode,
        },
        time: chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true),
    };
    serde_json::to_value(&health).map_err(|e| e.to_string())
}
