use std::path::PathBuf;

/// Parsed command-line configuration for the download-core process.
///
/// The process is launched by the Electron main process with explicit
/// arguments; it never reads configuration from arbitrary environment
/// sources for paths (only RUST_LOG for log filtering).
#[derive(Debug, Clone)]
pub struct CoreConfig {
    pub data_dir: PathBuf,
    pub log_level: tracing::Level,
}

impl CoreConfig {
    pub fn from_env_and_args() -> Result<Self, String> {
        let mut data_dir: Option<PathBuf> = None;
        let mut log_level: Option<tracing::Level> = None;

        let mut args = std::env::args().skip(1);
        while let Some(arg) = args.next() {
            match arg.as_str() {
                "--data-dir" => {
                    let value = args.next().ok_or("--data-dir requires a value")?;
                    data_dir = Some(PathBuf::from(value));
                }
                "--log-level" => {
                    let value = args.next().ok_or("--log-level requires a value")?;
                    log_level = Some(
                        value
                            .parse()
                            .map_err(|_| format!("invalid --log-level: {value}"))?,
                    );
                }
                other => return Err(format!("unknown argument: {other}")),
            }
        }

        Ok(Self {
            data_dir: data_dir.ok_or("--data-dir is required")?,
            log_level: log_level.unwrap_or(tracing::Level::INFO),
        })
    }
}
