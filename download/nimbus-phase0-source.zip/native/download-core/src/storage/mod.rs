use std::path::{Path, PathBuf};
use std::sync::Mutex;

use rusqlite::Connection;
use serde::Serialize;

/// Persistent storage is owned exclusively by the Rust core (ADR-0004).
/// The Electron main process never opens the database itself; it talks to
/// the core over RPC.
pub struct Storage {
    conn: Mutex<Connection>,
    path: PathBuf,
}

#[derive(Debug, thiserror::Error)]
pub enum StorageError {
    #[error("sqlite error: {0}")]
    Sqlite(#[from] rusqlite::Error),
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
}

pub type Result<T> = std::result::Result<T, StorageError>;

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct DbStatus {
    pub path: String,
    pub schema_version: i64,
    pub journal_mode: String,
}

impl Storage {
    pub fn open(data_dir: &Path) -> Result<Self> {
        std::fs::create_dir_all(data_dir)?;
        let path = data_dir.join("nimbus.db");
        let conn = Connection::open(&path)?;
        // Durability-first pragmas: WAL for concurrent read access from later
        // subsystems, NORMAL sync as the documented WAL-safe setting.
        conn.pragma_update(None, "journal_mode", "WAL")?;
        conn.pragma_update(None, "synchronous", "NORMAL")?;
        conn.pragma_update(None, "foreign_keys", "ON")?;
        let storage = Self {
            conn: Mutex::new(conn),
            path,
        };
        storage.migrate()?;
        Ok(storage)
    }

    /// Applies pending migrations in order. Each migration runs inside a
    /// transaction together with its bookkeeping row, so a crash mid-migration
    /// cannot leave a half-applied schema.
    fn migrate(&self) -> Result<()> {
        let conn = self.conn.lock().expect("storage mutex poisoned");
        conn.execute_batch(
            "CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                name TEXT NOT NULL,
                applied_at TEXT NOT NULL
            );",
        )?;

        for (version, name, sql) in migrations() {
            let already_applied: i64 = conn.query_row(
                "SELECT COUNT(*) FROM schema_migrations WHERE version = ?1",
                [version],
                |row| row.get(0),
            )?;
            if already_applied > 0 {
                continue;
            }

            let tx = conn.unchecked_transaction()?;
            tx.execute_batch(sql)?;
            tx.execute(
                "INSERT INTO schema_migrations (version, name, applied_at) VALUES (?1, ?2, ?3)",
                rusqlite::params![
                    version,
                    name,
                    chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Millis, true)
                ],
            )?;
            tx.commit()?;
            tracing::info!(version, name, "migration applied");
        }
        Ok(())
    }

    pub fn status(&self) -> Result<DbStatus> {
        let conn = self.conn.lock().expect("storage mutex poisoned");
        let schema_version: i64 = conn.query_row(
            "SELECT COALESCE(MAX(version), 0) FROM schema_migrations",
            [],
            |row| row.get(0),
        )?;
        let journal_mode: String =
            conn.query_row("PRAGMA journal_mode", [], |row| row.get(0))?;
        Ok(DbStatus {
            path: self.path.to_string_lossy().into_owned(),
            schema_version,
            journal_mode,
        })
    }
}

/// (version, name, batch SQL). New migrations are appended only — never edit
/// an already-shipped migration (ADR-0004).
fn migrations() -> Vec<(i64, &'static str, &'static str)> {
    vec![(
        1,
        "0001_core_meta",
        "CREATE TABLE app_meta (
             key TEXT PRIMARY KEY,
             value TEXT NOT NULL,
             updated_at TEXT NOT NULL
         );
         INSERT OR IGNORE INTO app_meta (key, value, updated_at)
         VALUES ('db_created_at', strftime('%Y-%m-%dT%H:%M:%fZ','now'), strftime('%Y-%m-%dT%H:%M:%fZ','now'));",
    )]
}
