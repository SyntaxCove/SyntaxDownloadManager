use tracing_subscriber::EnvFilter;

/// Initializes structured logging.
///
/// CRITICAL: stdout is the JSONL RPC channel to the Electron main process.
/// Logs are therefore written to stderr only, and the parent process is
/// responsible for capturing and forwarding them into its own log sink.
pub fn init(level: tracing::Level) {
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new(level.to_string()));
    tracing_subscriber::fmt()
        .with_writer(std::io::stderr)
        .with_env_filter(filter)
        .with_target(false)
        .init();
}
