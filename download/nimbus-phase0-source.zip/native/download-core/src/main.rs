use std::sync::Arc;

use download_core::{config::CoreConfig, logging, rpc, rpc::methods::health, storage::Storage};

fn main() {
    let config = match CoreConfig::from_env_and_args() {
        Ok(config) => config,
        Err(err) => {
            eprintln!("download-core: {err}");
            std::process::exit(2);
        }
    };

    logging::init(config.log_level);
    health::mark_start();

    let runtime = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("tokio runtime");

    let exit_code = runtime.block_on(async move {
        let storage = match Storage::open(&config.data_dir) {
            Ok(storage) => Arc::new(storage),
            Err(err) => {
                tracing::error!(error = %err, "storage initialization failed");
                return 1;
            }
        };
        tracing::info!(
            version = env!("CARGO_PKG_VERSION"),
            data_dir = %config.data_dir.display(),
            "download-core started"
        );
        rpc::serve(storage).await
    });

    std::process::exit(exit_code);
}
