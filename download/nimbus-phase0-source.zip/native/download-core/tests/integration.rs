use std::sync::Arc;

use download_core::rpc::{dispatch, Action, IncomingRequest, RpcId};
use download_core::storage::Storage;
use serde_json::{json, Value};

fn tmpdir(tag: &str) -> std::path::PathBuf {
    let dir = std::env::temp_dir().join(format!(
        "nimbus-core-it-{tag}-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    let _ = std::fs::remove_dir_all(&dir);
    std::fs::create_dir_all(&dir).unwrap();
    dir
}

fn request(id: RpcId, method: &str) -> IncomingRequest {
    IncomingRequest {
        jsonrpc: "2.0".to_string(),
        id,
        method: method.to_string(),
        params: Some(json!({})),
    }
}

fn reply_of(action: Action) -> Value {
    match action {
        Action::Reply(value) | Action::ReplyThenShutdown(value) => value,
    }
}

#[test]
fn health_matches_shared_contract_fixture() {
    let dir = tmpdir("fixture");
    let storage = Arc::new(Storage::open(&dir).unwrap());

    let action = dispatch(&storage, &request(RpcId::Number(1), "core.health"));
    let value = reply_of(action);

    let fixture: Value = serde_json::from_str(include_str!(
        "../../../tests/fixtures/health.check.response.json"
    ))
    .unwrap();
    let expected = fixture["result"].as_object().unwrap();
    let actual = value["result"].as_object().unwrap();

    // pid / uptimeMs / time are dynamic; every stable field must match the
    // shared fixture exactly, proving TS and Rust speak the same contract.
    for key in ["status", "name", "version"] {
        assert_eq!(actual.get(key), expected.get(key), "mismatch on {key}");
    }
    assert_eq!(actual["db"]["schemaVersion"], expected["db"]["schemaVersion"]);
    assert_eq!(actual["db"]["journalMode"], expected["db"]["journalMode"]);
}

#[test]
fn unknown_method_returns_method_not_found() {
    let dir = tmpdir("unknown");
    let storage = Arc::new(Storage::open(&dir).unwrap());

    let value = reply_of(dispatch(
        &storage,
        &request(RpcId::Number(2), "does.not.exist"),
    ));
    assert_eq!(value["error"]["code"], json!(-32601));
}

#[test]
fn migrations_are_durable_across_reopens() {
    let dir = tmpdir("migrate");
    {
        let storage = Storage::open(&dir).unwrap();
        assert_eq!(storage.status().unwrap().schema_version, 1);
    }
    {
        let storage = Storage::open(&dir).unwrap();
        let status = storage.status().unwrap();
        assert_eq!(status.schema_version, 1);
        assert_eq!(status.journal_mode, "wal");
    }
}

#[test]
fn app_meta_persists_values() {
    use rusqlite::Connection;

    let dir = tmpdir("meta");
    {
        let _storage = Storage::open(&dir).unwrap();
    }
    let conn = Connection::open(dir.join("nimbus.db")).unwrap();
    let created: String = conn
        .query_row(
            "SELECT value FROM app_meta WHERE key = 'db_created_at'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert!(created.ends_with('Z'), "created_at must be RFC3339 UTC");
}
