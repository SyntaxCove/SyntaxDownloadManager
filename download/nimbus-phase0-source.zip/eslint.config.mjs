import tseslint from 'typescript-eslint';

export default tseslint.config(
  {
    ignores: [
      '**/dist/**',
      '**/node_modules/**',
      '**/target/**',
      '**/.data/**',
      '**/resources/bin/**',
      '**/resources/locks/**',
      '**/coverage/**',
    ],
  },
  ...tseslint.configs.recommended,
  {
    rules: {
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/consistent-type-imports': ['error', { prefer: 'type-imports' }],
      'no-console': ['warn', { allow: ['log', 'warn', 'error'] }],
    },
  },
  {
    files: ['**/*.mjs', 'scripts/**/*.mjs', 'apps/desktop/scripts/**/*.mjs'],
    rules: {
      'no-console': 'off',
    },
  },
);
