import { create } from 'zustand';
import { AppInfoResult, CoreHealthResult, isRpcErrorResponse } from '@nimbus/contracts';
import type {
  AppInfoResult as AppInfo,
  CoreHealthResult as Health,
  CoreStatusEvent,
} from '@nimbus/contracts';

interface AppStore {
  appInfo: AppInfo | null;
  coreStatus: CoreStatusEvent | null;
  health: Health | null;
  healthError: string | null;
  healthLoading: boolean;
  boot: () => Promise<void>;
  runHealthCheck: () => Promise<void>;
  setCoreStatus: (status: CoreStatusEvent) => void;
}

/** Renderer-side RPC helper: unwraps the JSON-RPC envelope and validates the
 * result against its contract schema before it may enter UI state. */
async function rpc<T>(
  method: string,
  schema: { parse: (value: unknown) => T },
  params?: unknown,
): Promise<T> {
  const response: unknown = await window.nimbus.rpc(method, params);
  if (isRpcErrorResponse(response)) {
    throw new Error(response.error.message);
  }
  return schema.parse((response as { result: unknown }).result);
}

export const useAppStore = create<AppStore>((set, get) => ({
  appInfo: null,
  coreStatus: null,
  health: null,
  healthError: null,
  healthLoading: false,

  boot: async () => {
    try {
      set({ appInfo: await rpc('app.info', AppInfoResult) });
    } catch {
      // app.info failure is non-fatal for the status page; core status will
      // surface the actual problem.
    }
  },

  runHealthCheck: async () => {
    const status = get().coreStatus;
    if (status === null || status.state !== 'running') {
      set({ healthError: 'Core process is not running.', health: null });
      return;
    }
    set({ healthLoading: true, healthError: null });
    try {
      set({ health: await rpc('core.health', CoreHealthResult), healthLoading: false });
    } catch (err) {
      set({
        healthError: err instanceof Error ? err.message : String(err),
        healthLoading: false,
      });
    }
  },

  setCoreStatus: (status) => set({ coreStatus: status }),
}));
