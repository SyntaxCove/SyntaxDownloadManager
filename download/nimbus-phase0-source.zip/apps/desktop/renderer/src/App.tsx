import { useEffect } from 'react';
import { CoreStatusEvent } from '@nimbus/contracts';
import { useAppStore } from './store/appStore';
import { StatePill } from './components/StatePill';
import { KV, StatusCard } from './components/StatusCard';

function formatUptime(ms: number): string {
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) {
    return `${hours}h ${minutes}m ${seconds}s`;
  }
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

export function App() {
  const appInfo = useAppStore((s) => s.appInfo);
  const coreStatus = useAppStore((s) => s.coreStatus);
  const health = useAppStore((s) => s.health);
  const healthError = useAppStore((s) => s.healthError);
  const healthLoading = useAppStore((s) => s.healthLoading);

  useEffect(() => {
    void useAppStore.getState().boot();
  }, []);

  useEffect(() => {
    const unsubscribe = window.nimbus.onCoreStatus((payload) => {
      const parsed = CoreStatusEvent.safeParse(payload);
      if (parsed.success) {
        useAppStore.getState().setCoreStatus(parsed.data);
      }
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (
      coreStatus?.state === 'running' &&
      health === null &&
      !healthLoading &&
      healthError === null
    ) {
      void useAppStore.getState().runHealthCheck();
    }
  }, [coreStatus, health, healthLoading, healthError]);

  const onRunHealthCheck = (): void => {
    void useAppStore.getState().runHealthCheck();
  };

  return (
    <div className="app">
      <nav className="rail" aria-label="Primary">
        <div className="logo" title="Nimbus">
          N
        </div>
      </nav>

      <main className="main">
        <h1>System</h1>
        <p className="subtitle">
          Phase 0 — foundation status. Browser and download features arrive in later phases.
        </p>

        <div className="cards">
          <StatusCard title="Application">
            <KV k="App version" v={appInfo?.appVersion ?? '—'} />
            <KV k="Electron" v={appInfo?.electron ?? '—'} />
            <KV k="Chromium" v={appInfo?.chrome ?? '—'} />
            <KV k="Node" v={appInfo?.node ?? '—'} />
            <KV k="Platform" v={appInfo ? `${appInfo.platform} (${appInfo.arch})` : '—'} />
          </StatusCard>

          <StatusCard title="Core Process">
            <div className="pill-row">
              <StatePill state={coreStatus?.state ?? 'stopped'} />
              {coreStatus?.detail !== null && coreStatus?.detail !== undefined && (
                <span className="detail">{coreStatus.detail}</span>
              )}
            </div>
            <KV k="Version" v={health?.version ?? '—'} />
            <KV k="PID" v={health?.pid ?? coreStatus?.pid ?? '—'} />
            <KV k="Uptime" v={health ? formatUptime(health.uptimeMs) : '—'} />
            <div className="actions">
              <button
                type="button"
                className="btn primary"
                onClick={onRunHealthCheck}
                disabled={healthLoading || coreStatus?.state !== 'running'}
              >
                {healthLoading ? 'Checking…' : 'Run health check'}
              </button>
            </div>
            {healthError !== null && <p className="error-text">{healthError}</p>}
          </StatusCard>

          <StatusCard title="Database">
            <KV k="Schema version" v={health?.db.schemaVersion ?? '—'} />
            <KV k="Journal mode" v={health?.db.journalMode ?? '—'} />
            <KV k="Path" v={health?.db.path ?? '—'} mono />
          </StatusCard>
        </div>
      </main>

      <footer className="statusbar">
        <StatePill state={coreStatus?.state ?? 'stopped'} />
        <span>Contracts v{appInfo?.contractsVersion ?? '—'}</span>
        <span className="mono trunc">{health?.db.path ?? 'database not probed yet'}</span>
      </footer>
    </div>
  );
}
