import type { CoreStatusEvent } from '@nimbus/contracts';

const LABELS: Record<CoreStatusEvent['state'], string> = {
  stopped: 'Stopped',
  starting: 'Starting',
  running: 'Running',
  crashed: 'Crashed',
  backoff: 'Restarting',
};

export function StatePill({ state }: { state: CoreStatusEvent['state'] }) {
  return (
    <span className="pill">
      <span className={`dot ${state}`} />
      {LABELS[state] ?? state}
    </span>
  );
}
