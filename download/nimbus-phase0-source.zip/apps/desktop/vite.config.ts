import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

/**
 * CSP is strict in production builds (script-src 'self'). In dev, Vite's
 * React-refresh preamble requires 'unsafe-inline', which is only added when
 * a dev server is active (ctx.server) — never in the built bundle.
 */
function cspMeta(dev: boolean): string {
  const scriptSrc = dev ? "'self' 'unsafe-inline'" : "'self'";
  return `<meta http-equiv="Content-Security-Policy" content="default-src 'self'; script-src ${scriptSrc}; style-src 'self'; img-src 'self' data:; font-src 'self'">`;
}

export default defineConfig({
  root: 'renderer',
  base: './',
  plugins: [
    react(),
    {
      name: 'nimbus-csp',
      transformIndexHtml: {
        order: 'post',
        handler(html, ctx) {
          return html.replace('<!--CSP-->', cspMeta(Boolean(ctx.server)));
        },
      },
    },
  ],
  server: {
    port: 5173,
    strictPort: true,
  },
  build: {
    outDir: '../dist/renderer',
    emptyOutDir: true,
    target: 'esnext',
  },
});
