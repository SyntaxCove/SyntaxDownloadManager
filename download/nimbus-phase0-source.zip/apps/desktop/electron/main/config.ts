import { app } from 'electron';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { AppConfig, DEFAULT_APP_CONFIG } from '@nimbus/contracts';

/**
 * Configuration ownership (Phase 0): Electron main owns the small app-level
 * config file; the Rust core owns the durable task/download database.
 * Domains never write into each other's stores (ADR-0004).
 */
export function resolveDataDir(isPackaged: boolean): string {
  return isPackaged ? join(app.getPath('userData'), 'data') : join(__dirname, '..', '.data');
}

export function loadConfig(dataDir: string): AppConfig {
  mkdirSync(dataDir, { recursive: true });
  const file = join(dataDir, 'config.json');
  if (!existsSync(file)) {
    saveConfig(dataDir, DEFAULT_APP_CONFIG);
    return DEFAULT_APP_CONFIG;
  }
  try {
    const parsed = AppConfig.safeParse(JSON.parse(readFileSync(file, 'utf8')));
    return parsed.success ? parsed.data : DEFAULT_APP_CONFIG;
  } catch {
    return DEFAULT_APP_CONFIG;
  }
}

export function saveConfig(dataDir: string, config: AppConfig): void {
  mkdirSync(dataDir, { recursive: true });
  writeFileSync(join(dataDir, 'config.json'), `${JSON.stringify(config, null, 2)}\n`, 'utf8');
}
