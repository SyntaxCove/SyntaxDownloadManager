import { appendFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { redactSensitive } from '@nimbus/shared';
import type { LogDomain, LogLevelName, LogRecord } from '@nimbus/shared';

const LEVEL_WEIGHT: Record<LogLevelName, number> = {
  trace: 10,
  debug: 20,
  info: 30,
  warn: 40,
  error: 50,
};

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value) ?? 'null';
  } catch {
    return '"[unserializable]"';
  }
}

/**
 * Structured JSONL logger for the main process (master prompt §41).
 * - One line per record: {ts, level, domain, msg, data?}
 * - Free-form strings are passed through redactSensitive() before persisting.
 * - A sink failure must never crash the app.
 */
export class Logger {
  private threshold: number;
  private filePath: string | null = null;
  private mirror: boolean;

  constructor(level: LogLevelName, options?: { consoleMirror?: boolean }) {
    this.threshold = LEVEL_WEIGHT[level];
    this.mirror = options?.consoleMirror ?? false;
  }

  attachFileSink(dir: string): void {
    try {
      mkdirSync(dir, { recursive: true });
      this.filePath = join(dir, `main-${new Date().toISOString().slice(0, 10)}.log`);
    } catch {
      this.filePath = null;
    }
  }

  private write(level: LogLevelName, domain: LogDomain, msg: string, data?: unknown): void {
    if (LEVEL_WEIGHT[level] < this.threshold) {
      return;
    }
    const record: LogRecord = {
      ts: new Date().toISOString(),
      level,
      domain,
      msg: redactSensitive(msg),
    };
    if (data !== undefined) {
      record.data = JSON.parse(redactSensitive(safeStringify(data)));
    }
    const line = JSON.stringify(record);
    if (this.filePath !== null) {
      try {
        appendFileSync(this.filePath, `${line}\n`);
      } catch {
        // sink failure must never crash the app
      }
    }
    if (this.mirror || this.filePath === null) {
      console.log(line);
    }
  }

  trace(domain: LogDomain, msg: string, data?: unknown): void {
    this.write('trace', domain, msg, data);
  }

  debug(domain: LogDomain, msg: string, data?: unknown): void {
    this.write('debug', domain, msg, data);
  }

  info(domain: LogDomain, msg: string, data?: unknown): void {
    this.write('info', domain, msg, data);
  }

  warn(domain: LogDomain, msg: string, data?: unknown): void {
    this.write('warn', domain, msg, data);
  }

  error(domain: LogDomain, msg: string, data?: unknown): void {
    this.write('error', domain, msg, data);
  }
}
