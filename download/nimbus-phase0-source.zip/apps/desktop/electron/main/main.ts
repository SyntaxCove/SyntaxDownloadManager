import { app, BrowserWindow } from 'electron';
import path from 'node:path';
import { CoreHealthResult } from '@nimbus/contracts';
import { CoreProcessManager } from './core/process-manager';
import { loadConfig, resolveDataDir } from './config';
import { Logger } from './logger';
import { registerIpc } from './ipc/router';

const isSmoke = process.argv.includes('--smoke');
if (isSmoke) {
  app.disableHardwareAcceleration();
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let window: BrowserWindow | null = null;
let logger: Logger | null = null;
let core: CoreProcessManager | null = null;
let dataDir = '';
let smokeFinished = false;

function coreBinaryPath(): string {
  const binary = process.platform === 'win32' ? 'download-core.exe' : 'download-core';
  if (app.isPackaged) {
    return path.join(process.resourcesPath, 'resources', 'bin', 'download-core', binary);
  }
  return path.join(__dirname, '..', '..', '..', 'native', 'target', 'release', binary);
}

function appInfo(): unknown {
  return {
    appVersion: app.getVersion(),
    electron: process.versions.electron ?? 'unknown',
    chrome: process.versions.chrome ?? 'unknown',
    node: process.versions.node ?? 'unknown',
    platform: process.platform,
    arch: process.arch,
    locale: app.getLocale(),
    contractsVersion: 1,
  };
}

function finishSmoke(ok: boolean, detail: string): void {
  if (!isSmoke || smokeFinished) {
    return;
  }
  smokeFinished = true;
  if (ok) {
    console.log(`SMOKE_OK ${detail}`);
  } else {
    console.error(`SMOKE_FAIL ${detail}`);
  }
  setTimeout(() => app.exit(ok ? 0 : 1), 150);
}

async function shutdownCore(): Promise<void> {
  if (core !== null) {
    await core.stop();
  }
}

function createWindow(): void {
  window = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 960,
    minHeight: 600,
    backgroundColor: '#202020',
    title: 'Nimbus',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      sandbox: true,
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });

  window.once('ready-to-show', () => {
    window?.show();
  });

  const devUrl = process.env.NIMBUS_RENDERER_URL;
  if (devUrl) {
    void window.loadURL(devUrl);
  } else {
    void window.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  }

  window.webContents.on('did-finish-load', () => {
    if (isSmoke && core !== null) {
      core
        .request('core.health', {}, 8_000)
        .then((result) => {
          const health = CoreHealthResult.parse(result);
          finishSmoke(
            true,
            `core=${health.version} db.schemaVersion=${health.db.schemaVersion} journal=${health.db.journalMode}`,
          );
        })
        .catch((err: unknown) => {
          finishSmoke(false, err instanceof Error ? err.message : String(err));
        });
    }
  });

  window.on('closed', () => {
    window = null;
  });
}

app.whenReady().then(() => {
  dataDir = resolveDataDir(app.isPackaged);
  const config = loadConfig(dataDir);

  logger = new Logger(config.logLevel, { consoleMirror: isSmoke });
  logger.attachFileSink(path.join(dataDir, 'logs'));
  logger.info('app', 'nimbus starting', { version: app.getVersion(), smoke: isSmoke });

  core = new CoreProcessManager(coreBinaryPath(), dataDir, config.logLevel, logger);
  core.on('status', (event: unknown) => {
    if (logger !== null && typeof event === 'object' && event !== null) {
      const state = (event as { state?: unknown }).state;
      logger.info('app', 'core status change', { state });
    }
    if (window !== null && !window.isDestroyed()) {
      window.webContents.send('core:status', event);
    }
  });

  registerIpc({ core, config, dataDir }, appInfo, logger);

  createWindow();
  core.start();

  if (isSmoke) {
    setTimeout(() => finishSmoke(false, 'smoke timeout after 30s'), 30_000);
  }

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('second-instance', () => {
  if (window !== null) {
    if (window.isMinimized()) {
      window.restore();
    }
    window.focus();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

let coreStopped = false;
app.on('will-quit', (event) => {
  if (!coreStopped) {
    event.preventDefault();
    coreStopped = true;
    void shutdownCore().finally(() => app.quit());
  }
});

process.on('uncaughtException', (err) => {
  logger?.error('app', 'uncaught exception', { message: err.message, stack: err.stack });
});

process.on('unhandledRejection', (reason) => {
  logger?.error('app', 'unhandled rejection', {
    message: reason instanceof Error ? reason.message : String(reason),
  });
});
