import { ipcMain } from 'electron';
import {
  APP_METHODS,
  AppInfoResult,
  CONFIG_METHODS,
  ConfigGetResult,
  RendererRpcRequest,
  RpcErrorCode,
  makeError,
  makeSuccess,
} from '@nimbus/contracts';
import type { AppConfig } from '@nimbus/contracts';
import type { Logger } from '../logger';
import type { CoreProcessManager } from '../core/process-manager';

const RPC_CHANNEL = 'nimbus:rpc';
const CORE_RPC_TIMEOUT_MS = 10_000;

export interface RouterContext {
  core: CoreProcessManager;
  config: AppConfig;
  dataDir: string;
}

/**
 * Typed IPC boundary (master prompt §6). The renderer can only invoke the
 * single whitelisted channel with a {method, params} payload; every payload
 * is validated with zod before any handler runs, and every response is a
 * valid JSON-RPC envelope. Unknown methods are rejected, never guessed.
 */
export function registerIpc(ctx: RouterContext, appInfo: () => unknown, log: Logger): void {
  let requestId = 1;

  ipcMain.handle(RPC_CHANNEL, async (_event, rawPayload: unknown) => {
    const parsed = RendererRpcRequest.safeParse(rawPayload);
    if (!parsed.success) {
      return makeError(null, RpcErrorCode.INVALID_REQUEST, 'malformed rpc payload');
    }
    const { method, params } = parsed.data;
    const id = requestId++;

    try {
      if (method === APP_METHODS.info) {
        return makeSuccess(id, AppInfoResult.parse(appInfo()));
      }
      if (method === CONFIG_METHODS.get) {
        return makeSuccess(
          id,
          ConfigGetResult.parse({ logLevel: ctx.config.logLevel, dataDir: ctx.dataDir }),
        );
      }
      if (method.startsWith('core.')) {
        const result = await ctx.core.request(method, params, CORE_RPC_TIMEOUT_MS);
        return makeSuccess(id, result);
      }
      return makeError(id, RpcErrorCode.METHOD_NOT_FOUND, `method not allowed: ${method}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      log.warn('ipc', 'rpc handler failed', { method, message });
      return makeError(id, RpcErrorCode.CORE_FAILURE, message);
    }
  });
}
