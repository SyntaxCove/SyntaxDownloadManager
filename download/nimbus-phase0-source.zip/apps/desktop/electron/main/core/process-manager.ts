import { spawn } from 'node:child_process';
import type { ChildProcessWithoutNullStreams } from 'node:child_process';
import { existsSync } from 'node:fs';
import { createInterface } from 'node:readline';
import { EventEmitter } from 'node:events';
import { CoreHealthResult, CoreStatusEvent } from '@nimbus/contracts';
import type { CoreHealthResult as CoreHealthResultType, CoreProcessState } from '@nimbus/contracts';
import type { Logger } from '../logger';

interface PendingRequest {
  resolve: (result: unknown) => void;
  reject: (error: Error) => void;
  timer: NodeJS.Timeout;
}

const RESTART_BASE_DELAY_MS = 500;
const RESTART_MAX_DELAY_MS = 8_000;
const DEFAULT_RPC_TIMEOUT_MS = 10_000;

/**
 * Supervises the download-core.exe child process (master prompt §5).
 *
 * - Speaks JSONL JSON-RPC 2.0 over the child's stdio.
 * - Restarts the child with exponential backoff after crashes (an intentional
 *   stop never triggers a restart).
 * - All outgoing lines are validated against the shared contracts before
 *   being emitted to the renderer.
 */
export class CoreProcessManager extends EventEmitter {
  private child: ChildProcessWithoutNullStreams | null = null;
  private state: CoreProcessState = 'stopped';
  private readonly pending = new Map<number, PendingRequest>();
  private nextRequestId = 1;
  private restarts = 0;
  private intentionalStop = false;
  private backoffTimer: NodeJS.Timeout | null = null;
  private lastHealth: CoreHealthResultType | null = null;

  constructor(
    private readonly binaryPath: string,
    private readonly dataDir: string,
    private readonly logLevel: string,
    private readonly log: Logger,
  ) {
    super();
  }

  getState(): CoreProcessState {
    return this.state;
  }

  getLastHealth(): CoreHealthResultType | null {
    return this.lastHealth;
  }

  start(): void {
    if (this.child !== null || this.backoffTimer !== null) {
      return;
    }
    if (!existsSync(this.binaryPath)) {
      this.setState('crashed', null, `core binary not found: ${this.binaryPath}`);
      return;
    }

    this.intentionalStop = false;
    this.setState('starting', null);
    try {
      this.child = spawn(
        this.binaryPath,
        ['--data-dir', this.dataDir, '--log-level', this.logLevel],
        { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true },
      );
    } catch (err) {
      this.child = null;
      this.setState('crashed', null, err instanceof Error ? err.message : String(err));
      return;
    }

    const child = this.child;
    const pid = child.pid ?? null;
    this.log.info('app', 'core process spawned', { pid, binary: this.binaryPath });

    createInterface({ input: child.stdout }).on('line', (line) => this.handleStdoutLine(line));
    createInterface({ input: child.stderr }).on('line', (line) =>
      this.log.debug('app', `[core] ${line}`),
    );

    child.on('error', (err) => {
      this.log.error('app', 'core process error', { message: err.message });
    });

    child.on('exit', (code, signal) => {
      this.child = null;
      this.rejectAllPending(new Error(`core exited (code=${code} signal=${signal})`));
      if (this.intentionalStop) {
        this.setState('stopped', null);
        return;
      }
      this.setState('crashed', null, `exit code=${code} signal=${signal}`);
      this.scheduleRestart();
    });

    this.setState('running', pid);
    this.refreshHealth();
  }

  /** Fire-and-forget health probe used to flip state into a verified run. */
  private refreshHealth(): void {
    this.request('core.health', {}, 8_000)
      .then((result) => {
        this.lastHealth = CoreHealthResult.parse(result);
        this.restarts = 0;
        this.log.info('app', 'core health check passed', {
          version: this.lastHealth.version,
          schemaVersion: this.lastHealth.db.schemaVersion,
        });
      })
      .catch((err: unknown) => {
        this.log.warn('app', 'core health check failed', {
          message: err instanceof Error ? err.message : String(err),
        });
      });
  }

  request(method: string, params?: unknown, timeoutMs = DEFAULT_RPC_TIMEOUT_MS): Promise<unknown> {
    const child = this.child;
    if (child === null) {
      return Promise.reject(new Error('core is not running'));
    }
    const id = this.nextRequestId++;
    const payload: Record<string, unknown> = { jsonrpc: '2.0', id, method };
    if (params !== undefined) {
      payload.params = params;
    }

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`core rpc timeout: ${method}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      child.stdin.write(`${JSON.stringify(payload)}\n`, (err) => {
        if (err) {
          clearTimeout(timer);
          this.pending.delete(id);
          reject(err);
        }
      });
    });
  }

  async stop(): Promise<void> {
    this.intentionalStop = true;
    if (this.backoffTimer !== null) {
      clearTimeout(this.backoffTimer);
      this.backoffTimer = null;
    }
    const child = this.child;
    if (child === null) {
      this.setState('stopped', null);
      return;
    }
    await new Promise<void>((resolve) => {
      const forceTimer = setTimeout(() => {
        child.kill('SIGKILL');
        resolve();
      }, 3_000);
      child.once('exit', () => {
        clearTimeout(forceTimer);
        resolve();
      });
      child.kill();
    });
    this.child = null;
    this.setState('stopped', null);
  }

  private handleStdoutLine(line: string): void {
    const trimmed = line.trim();
    if (trimmed.length === 0) {
      return;
    }
    let message: unknown;
    try {
      message = JSON.parse(trimmed);
    } catch {
      this.log.warn('app', 'unparseable line from core stdout', { line: trimmed.slice(0, 200) });
      return;
    }
    if (typeof message !== 'object' || message === null || !('id' in message)) {
      return;
    }
    const id = (message as { id: unknown }).id;
    if (typeof id !== 'number') {
      return;
    }
    const entry = this.pending.get(id);
    if (entry === undefined) {
      return;
    }
    this.pending.delete(id);
    clearTimeout(entry.timer);
    if ('error' in message && typeof (message as { error: unknown }).error === 'object') {
      const error = (message as { error: { message?: unknown } }).error;
      entry.reject(new Error(typeof error.message === 'string' ? error.message : 'core rpc error'));
      return;
    }
    entry.resolve((message as { result?: unknown }).result);
  }

  private rejectAllPending(error: Error): void {
    for (const [id, entry] of this.pending) {
      clearTimeout(entry.timer);
      entry.reject(error);
      this.pending.delete(id);
    }
  }

  private scheduleRestart(): void {
    const delay = Math.min(RESTART_BASE_DELAY_MS * 2 ** this.restarts, RESTART_MAX_DELAY_MS);
    this.restarts += 1;
    this.setState('backoff', null, `restart #${this.restarts} in ${delay}ms`);
    this.backoffTimer = setTimeout(() => {
      this.backoffTimer = null;
      this.start();
    }, delay);
  }

  private setState(
    state: CoreProcessState,
    pid: number | null,
    detail: string | null = null,
  ): void {
    this.state = state;
    const event = CoreStatusEvent.parse({
      state,
      pid,
      restarts: this.restarts,
      detail,
    });
    this.emit('status', event);
  }
}
