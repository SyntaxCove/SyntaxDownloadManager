import { contextBridge, ipcRenderer } from 'electron';

/**
 * Minimal, sandboxed preload (master prompt §38). Only two capabilities are
 * exposed: validated RPC calls and the core-status event subscription.
 * No filesystem, no shell, no arbitrary command execution.
 */
const api = {
  rpc: (method: string, params?: unknown): Promise<unknown> =>
    ipcRenderer.invoke('nimbus:rpc', { method, params }),
  onCoreStatus: (listener: (payload: unknown) => void): (() => void) => {
    const wrapped = (_event: unknown, payload: unknown): void => listener(payload);
    ipcRenderer.on('core:status', wrapped);
    return () => {
      ipcRenderer.removeListener('core:status', wrapped);
    };
  },
};

contextBridge.exposeInMainWorld('nimbus', api);
