import type { CoreStatusEvent } from '@nimbus/contracts';

export interface NimbusApi {
  rpc(method: string, params?: unknown): Promise<unknown>;
  onCoreStatus(listener: (payload: CoreStatusEvent) => void): () => void;
}

declare global {
  interface Window {
    nimbus: NimbusApi;
  }
}

export {};
