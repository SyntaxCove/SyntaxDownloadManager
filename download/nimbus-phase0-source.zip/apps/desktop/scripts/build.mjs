import { build } from 'esbuild';
import { spawnSync } from 'node:child_process';
import process from 'node:process';

// 1) Renderer (vite build -> dist/renderer)
const vite = spawnSync('vite', ['build'], {
  stdio: 'inherit',
  shell: process.platform === 'win32',
});
if (vite.status !== 0) {
  process.exit(vite.status ?? 1);
}

// 2) Main + preload bundles (esbuild -> dist/main.js, dist/preload.js).
// CJS output keeps sandboxed preload compatibility and single-file packaging.
await build({
  entryPoints: ['electron/main/main.ts', 'electron/preload/preload.ts'],
  outdir: 'dist',
  entryNames: '[name]',
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node22',
  external: ['electron'],
  sourcemap: true,
  logLevel: 'info',
});
