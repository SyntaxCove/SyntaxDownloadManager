import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join, resolve } from 'node:path';
import process from 'node:process';

// Headless smoke test (Phase 0 acceptance): launches Electron, waits for the
// renderer to load AND the Rust core health check to pass, then exits.
//
// On a Linux box without a display, a private Xvfb is started for the test
// and Chromium flags (--no-sandbox --disable-gpu) are added ONLY for this
// headless CI scenario; packaged/normal runs are unaffected.

const APP_ROOT = resolve(import.meta.dirname, '..');
const ROOT = resolve(APP_ROOT, '..', '..');

if (
  !existsSync(join(APP_ROOT, 'dist', 'main.js')) ||
  !existsSync(join(APP_ROOT, 'dist', 'renderer', 'index.html'))
) {
  console.error('SMOKE_FAIL build output missing — run "pnpm build" and "pnpm core:build" first');
  process.exit(1);
}

const binaryName = process.platform === 'win32' ? 'electron.exe' : 'electron';
const electronBin = join(APP_ROOT, 'node_modules', '.bin', binaryName);
if (!existsSync(electronBin)) {
  console.error(`SMOKE_FAIL electron not found at ${electronBin}`);
  process.exit(1);
}

let xvfb = null;
if (process.platform === 'linux' && !process.env.DISPLAY) {
  xvfb = spawn('Xvfb', [':99', '-screen', '0', '1280x800x24', '-nolisten', 'tcp'], {
    stdio: 'ignore',
  });
  xvfb.on('error', () => {
    console.error('SMOKE_FAIL Xvfb unavailable and DISPLAY is not set');
    process.exit(1);
  });
  process.env.DISPLAY = ':99';
  await new Promise((r) => setTimeout(r, 1500));
}

const args = ['.'];
if (xvfb !== null) {
  args.push('--no-sandbox', '--disable-gpu'); // headless CI only
}
args.push('--smoke');

const child = spawn(electronBin, args, {
  cwd: APP_ROOT,
  env: process.env,
  stdio: ['ignore', 'pipe', 'pipe'],
});

let stdout = '';
let stderr = '';
child.stdout.on('data', (c) => {
  stdout += String(c);
});
child.stderr.on('data', (c) => {
  stderr += String(c);
});

const timeout = setTimeout(() => {
  console.error('SMOKE_FAIL timeout after 45s');
  child.kill('SIGKILL');
}, 45_000);

child.on('exit', (code) => {
  clearTimeout(timeout);
  process.stdout.write(stdout);
  process.stderr.write(
    stderr
      .split('\n')
      .filter((l) => !l.includes('dbus'))
      .join('\n'),
  );
  const ok = stdout.includes('SMOKE_OK') && code === 0;
  console.log(ok ? 'smoke: PASS' : 'smoke: FAIL');
  if (xvfb !== null) {
    xvfb.kill();
  }
  process.exit(ok ? 0 : 1);
});
