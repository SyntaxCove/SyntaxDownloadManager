import esbuild from 'esbuild';
import { spawn } from 'node:child_process';
import process from 'node:process';

const children = [];
const killAll = () => {
  for (const child of children) {
    try {
      child.kill();
    } catch {
      // already dead
    }
  }
};
process.on('SIGINT', () => {
  killAll();
  process.exit(0);
});
process.on('SIGTERM', () => {
  killAll();
  process.exit(0);
});

// 1) esbuild watch for main + preload (initial build synchronous so electron
// can launch immediately afterwards)
const ctx = await esbuild.context({
  entryPoints: ['electron/main/main.ts', 'electron/preload/preload.ts'],
  outdir: 'dist',
  entryNames: '[name]',
  bundle: true,
  platform: 'node',
  format: 'cjs',
  target: 'node22',
  external: ['electron'],
  sourcemap: true,
  logLevel: 'info',
});
await ctx.rebuild();
await ctx.watch();

// 2) vite dev server for the renderer
const vite = spawn('vite', [], {
  stdio: ['ignore', 'pipe', 'inherit'],
  shell: process.platform === 'win32',
});
children.push(vite);

const devUrl = await new Promise((resolve, reject) => {
  const timeout = setTimeout(
    () => reject(new Error('vite dev server did not start within 30s')),
    30_000,
  );
  vite.stdout.on('data', (chunk) => {
    const text = String(chunk);
    process.stdout.write(text);
    const match = text.match(/https?:\/\/localhost:\d+\//);
    if (match !== null) {
      clearTimeout(timeout);
      resolve(match[0]);
    }
  });
  vite.on('exit', (code) => reject(new Error(`vite exited early (code=${code})`)));
});

// 3) electron
const electron = spawn('electron', ['.'], {
  stdio: 'inherit',
  env: { ...process.env, NIMBUS_RENDERER_URL: devUrl },
  shell: process.platform === 'win32',
});
children.push(electron);

await new Promise((resolve) => electron.on('exit', resolve));
killAll();
await ctx.dispose();
