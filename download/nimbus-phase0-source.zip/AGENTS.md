# AGENTS.md — Operating Manual for AI Agents

This repository is built phase-by-phase by AI agents under human direction.
This file is the binding operating manual. Read it fully before touching code.

## Project

**Nimbus** — a Windows 11 unified browser + advanced download manager.

- Shell: Electron (Chromium via `WebContentsView` for tabs — never the deprecated `BrowserView`)
- Renderer: React + TypeScript + Vite + Zustand (stores organized by domain)
- Native core: Rust (`download-core`) — a supervised child process, never a separate user installation
- Persistence: SQLite, owned exclusively by the Rust core
- Bundled resources: yt-dlp, Deno, FFmpeg/FFprobe (no user-installed helpers)

## Prime directive

> A failed download must almost never force the user to start from zero when
> the already-downloaded bytes are still valid.

Engineering priority order (never trade downwards):

1. Data integrity 2. Security 3. Reliability/recovery 4. Correctness
2. Maintainability 6. Performance 7. UX 8. Feature breadth

## Hard rules

1. **No fake implementations.** No `TODO`, `FIXME`, `placeholder`, `mock`
   production paths, `return null`, or `throw "not implemented"` unless the
   item is an explicitly planned future phase hidden behind a real interface.
2. **Contract-first.** Every cross-boundary payload is defined in
   `packages/contracts` (zod) and mirrored in Rust (serde). Both sides are
   validated. The shared fixtures in `tests/fixtures/` are enforced by tests
   on both sides. Bump `CONTRACTS_VERSION` on non-additive wire changes.
3. **Typed IPC only.** The renderer never invokes arbitrary commands. All
   renderer→main traffic goes through the whitelisted `nimbus:rpc` channel
   with validated payloads. Unknown methods are rejected.
4. **Security is a requirement.** No Node integration in remote pages,
   context isolation always, sandbox on, minimal preload, no secrets in logs,
   no `cmd.exe /c ...` from untrusted input, explicit executable paths +
   argument arrays for every spawned tool (yt-dlp, ffmpeg, deno, download-core).
5. **No data loss.** Never delete valid partial data because a request failed.
   Never write to the final filename while incomplete. Atomic finalize only.
6. **No untrusted renderer input.** Validate at every boundary (zod on TS
   side, serde + explicit checks on Rust side).
7. **Phase discipline.** Work = plan → implement → test → fix → document →
   review → commit. Never proceed to the next phase before the current one
   passes its acceptance criteria. Never implement multiple phases in one
   uncontrolled change.
8. **Do not rewrite working subsystems** without a documented technical
   reason (ADR).

## Repository map

```
apps/desktop/         Electron shell (main, preload, renderer, build scripts)
packages/contracts/   Versioned zod IPC/data contracts (source of truth)
packages/shared/      Error codes, log domains, redaction helpers
packages/config/      Shared tsconfig base
native/download-core/ Rust core: rpc/, storage/, (future: downloader/,
                      recovery/, segments/, proxy/, media/, torrent/, scheduler/)
resources/            manifest.json + fetched binaries (bin/) + locks/
tests/fixtures/       Shared cross-language contract fixtures
tests/integration/    Cross-process tests
scripts/              fetch-resources.mjs, dist.mjs
docs/                 architecture/, adr/, reports/, licenses/
.github/workflows/    CI (linux test matrix + windows packaging)
```

## Commands

| Task                    | Command                                         |
| ----------------------- | ----------------------------------------------- |
| Install                 | `pnpm install`                                  |
| Dev (all processes)     | `pnpm dev`                                      |
| Typecheck               | `pnpm typecheck`                                |
| Lint                    | `pnpm lint`                                     |
| Contract tests          | `pnpm test:contracts`                           |
| Rust tests              | `pnpm core:test`                                |
| Build core (release)    | `pnpm core:build`                               |
| Integration test        | `pnpm test:integration`                         |
| Headless smoke test     | `pnpm smoke`                                    |
| Full test suite         | `pnpm test`                                     |
| Fetch bundled resources | `pnpm resources:fetch`                          |
| Verify resources        | `pnpm resources:verify`                         |
| Windows installer       | `pnpm dist` (on Windows, after resources:fetch) |

## Per-phase workflow (mandatory)

1. Inspect current repository state (read, don't assume).
2. Read relevant docs under `docs/architecture/`.
3. Determine what already exists.
4. Write a short implementation plan.
5. Implement the smallest coherent slice.
6. `pnpm typecheck && pnpm lint`.
7. `pnpm test:contracts` + `pnpm core:test`.
8. Integration tests.
9. E2E/smoke when applicable.
10. Fix every failure before continuing.
11. Update documentation (architecture docs + ADRs).
12. Security & regression review.
13. One clean, reviewable git commit for the phase slice.

Never claim a phase is complete if its acceptance criteria are unmet. Report
exactly what is done and what remains.

## Ambiguity policy

Do not stop for minor decisions. Prefer the choice that (a) minimizes
long-term coupling, (b) has the strongest maintenance ecosystem, (c) uses
official/documented APIs, (d) is simple and testable. Record the decision as
an ADR in `docs/adr/`. Stop only when a decision would fundamentally change
the product.

## Conventions

- TypeScript strict; no `any`; `import type` for type-only imports.
- Rust: `cargo fmt`-clean; errors via typed enums; `tracing` for logs.
- Logs are structured JSONL with domains (`app`, `download`, `recovery`,
  `media`, `proxy`, `torrent`, `database`, `ipc`, `packaging`, `browser`).
- Sensitive strings pass through `redactSensitive()` before logging.
- **stdout of download-core is the RPC channel** — the core never writes
  logs to stdout.
- Windows-safe filename generation and path validation are mandatory for any
  feature that names files (reserved names, `..`, UNC, trailing dots/spaces).
