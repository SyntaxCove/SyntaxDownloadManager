/** Structured log domains (master prompt §41). Sensitive data must be redacted. */
export const LOG_DOMAINS = [
  'app',
  'download',
  'recovery',
  'media',
  'proxy',
  'torrent',
  'database',
  'ipc',
  'packaging',
  'browser',
] as const;

export type LogDomain = (typeof LOG_DOMAINS)[number];

export type LogLevelName = 'trace' | 'debug' | 'info' | 'warn' | 'error';

export interface LogRecord {
  ts: string;
  level: LogLevelName;
  domain: LogDomain;
  msg: string;
  data?: unknown;
}

/**
 * Redacts obviously sensitive material from free-form strings before they are
 * written to logs: credentials in query strings, basic auth, bearer tokens.
 */
export function redactSensitive(input: string): string {
  return input
    .replace(/(token|key|secret|password|passwd|authorization)=([^&\s]+)/gi, '$1=***')
    .replace(/bearer\s+[\w.-]+/gi, 'bearer ***')
    .replace(/basic\s+[\w.=]+/gi, 'basic ***');
}
