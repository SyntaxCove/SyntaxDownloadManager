import { z } from 'zod';

/**
 * JSON-RPC 2.0 wire envelope, shared by the Electron main process and the
 * Rust download-core over JSONL stdio. Schemas are the source of truth; the
 * Rust side mirrors these shapes with serde (see ADR-0003).
 */
export const RPC_PROTOCOL = '2.0' as const;

export const JsonRpcId = z.union([z.string(), z.number()]);
export type JsonRpcId = z.infer<typeof JsonRpcId>;

/** Wire-level error codes (JSON-RPC reserved range + Nimbus core range). */
export const RpcErrorCode = {
  PARSE: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL: -32603,
  CORE_FAILURE: -32000,
  VALIDATION: -32001,
  UNAVAILABLE: -32002,
} as const;

export const RpcErrorPayload = z.object({
  code: z.number().int(),
  message: z.string().min(1),
  data: z.unknown().optional(),
});
export type RpcErrorPayload = z.infer<typeof RpcErrorPayload>;

export const RpcRequest = z.object({
  jsonrpc: z.literal(RPC_PROTOCOL),
  id: JsonRpcId,
  method: z.string().min(1),
  params: z.unknown().optional(),
});
export type RpcRequest = z.infer<typeof RpcRequest>;

export const RpcSuccessResponse = z.object({
  jsonrpc: z.literal(RPC_PROTOCOL),
  id: JsonRpcId,
  result: z.unknown(),
});
export type RpcSuccessResponse = z.infer<typeof RpcSuccessResponse>;

export const RpcErrorResponse = z.object({
  jsonrpc: z.literal(RPC_PROTOCOL),
  id: JsonRpcId.nullable(),
  error: RpcErrorPayload,
});
export type RpcErrorResponse = z.infer<typeof RpcErrorResponse>;

export const RpcResponse = z.union([RpcSuccessResponse, RpcErrorResponse]);
export type RpcResponse = z.infer<typeof RpcResponse>;

/** Payload the renderer is allowed to send over the typed IPC bridge. */
export const RendererRpcRequest = z.object({
  method: z.string().min(1),
  params: z.unknown().optional(),
});
export type RendererRpcRequest = z.infer<typeof RendererRpcRequest>;

export function makeSuccess(id: JsonRpcId, result: unknown): RpcSuccessResponse {
  return { jsonrpc: RPC_PROTOCOL, id, result };
}

export function makeError(
  id: JsonRpcId | null,
  code: number,
  message: string,
  data?: unknown,
): RpcErrorResponse {
  return {
    jsonrpc: RPC_PROTOCOL,
    id,
    error: data === undefined ? { code, message } : { code, message, data },
  };
}

export function isRpcErrorResponse(value: unknown): value is RpcErrorResponse {
  const parsed = RpcErrorResponse.safeParse(value);
  return parsed.success;
}
