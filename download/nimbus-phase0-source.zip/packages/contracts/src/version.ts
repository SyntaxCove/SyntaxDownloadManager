/**
 * Contracts versioning.
 *
 * CONTRACTS_VERSION is the single integer that both sides of every boundary
 * (renderer <-> main, main <-> download-core) must agree on. Whenever a wire
 * format changes in a non-additive way, bump this number and update the Rust
 * mirror in native/download-core/src/rpc accordingly.
 */
export const CONTRACTS_VERSION = 1 as const;
export const CONTRACTS_PROTOCOL_NAME = 'nimbus.ipc' as const;
