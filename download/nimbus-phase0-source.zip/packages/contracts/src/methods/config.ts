import { z } from 'zod';

/** Structured log levels, shared with the Rust core (tracing) and main logger. */
export const LOG_LEVELS = ['trace', 'debug', 'info', 'warn', 'error'] as const;

export const LogLevel = z.enum(LOG_LEVELS);
export type LogLevel = z.infer<typeof LogLevel>;

/** Persisted application configuration (owned by Electron main). */
export const AppConfig = z.object({
  logLevel: LogLevel,
});
export type AppConfig = z.infer<typeof AppConfig>;

export const DEFAULT_APP_CONFIG: AppConfig = { logLevel: 'info' };

export const ConfigGetResult = z.object({
  logLevel: LogLevel,
  dataDir: z.string().min(1),
});
export type ConfigGetResult = z.infer<typeof ConfigGetResult>;

export const CONFIG_METHODS = {
  get: 'config.get',
} as const;
