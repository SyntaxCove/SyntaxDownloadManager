import { z } from 'zod';

/** app.* methods: handled locally by the Electron main process. */
export const AppInfoResult = z.object({
  appVersion: z.string(),
  electron: z.string(),
  chrome: z.string(),
  node: z.string(),
  platform: z.string(),
  arch: z.string(),
  locale: z.string(),
  contractsVersion: z.number().int(),
});
export type AppInfoResult = z.infer<typeof AppInfoResult>;

export const APP_METHODS = {
  info: 'app.info',
} as const;
