import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { CoreHealthResult, CoreStatusEvent, RpcRequest, RpcSuccessResponse } from '../src/index.ts';

const fixturePath = (name: string) => resolve(import.meta.dirname, '../../../tests/fixtures', name);

const requestFixture = JSON.parse(readFileSync(fixturePath('health.check.request.json'), 'utf8'));
const responseFixture = JSON.parse(readFileSync(fixturePath('health.check.response.json'), 'utf8'));

describe('contract fixtures', () => {
  it('health.check request fixture conforms to RpcRequest', () => {
    expect(RpcRequest.safeParse(requestFixture).success).toBe(true);
  });

  it('health.check response fixture conforms to RpcSuccessResponse + CoreHealthResult', () => {
    const parsed = RpcSuccessResponse.safeParse(responseFixture);
    expect(parsed.success).toBe(true);
    const result = CoreHealthResult.safeParse(responseFixture.result);
    expect(result.success).toBe(true);
  });
});

describe('CoreHealthResult validation', () => {
  const valid = {
    status: 'ok',
    name: 'download-core',
    version: '0.1.0',
    pid: 4242,
    uptimeMs: 42,
    db: { path: '/tmp/nimbus.db', schemaVersion: 1, journalMode: 'wal' },
    time: '2026-09-29T00:00:00.000Z',
  };

  it('accepts a valid payload', () => {
    expect(CoreHealthResult.safeParse(valid).success).toBe(true);
  });

  it('rejects a non-positive pid', () => {
    expect(CoreHealthResult.safeParse({ ...valid, pid: 0 }).success).toBe(false);
  });

  it('rejects an unknown status literal', () => {
    expect(CoreHealthResult.safeParse({ ...valid, status: 'green' }).success).toBe(false);
  });

  it('rejects a negative schema version', () => {
    expect(
      CoreHealthResult.safeParse({ ...valid, db: { ...valid.db, schemaVersion: -1 } }).success,
    ).toBe(false);
  });
});

describe('CoreStatusEvent validation', () => {
  const valid = { state: 'running', pid: 4242, restarts: 0, detail: null };

  it('accepts null pid while stopped', () => {
    expect(CoreStatusEvent.safeParse({ ...valid, state: 'stopped', pid: null }).success).toBe(true);
  });

  it('rejects an unknown state', () => {
    expect(CoreStatusEvent.safeParse({ ...valid, state: 'zombie' }).success).toBe(false);
  });
});

describe('envelope helpers', () => {
  it('rejects a request with an unexpected protocol version', () => {
    expect(RpcRequest.safeParse({ ...requestFixture, jsonrpc: '1.0' }).success).toBe(false);
  });

  it('rejects a request without an id', () => {
    const requestWithoutId = { ...requestFixture };
    delete (requestWithoutId as { id?: unknown }).id;
    expect(RpcRequest.safeParse(requestWithoutId).success).toBe(false);
  });
});
