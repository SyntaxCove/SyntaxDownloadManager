# Nimbus — Unified Browser & Download Manager for Windows 11

Nimbus combines a Chromium-based browser with a production-grade download
manager whose defining principle is:

> **URL expired ≠ download lost.** A failed download reacquires its source,
> validates that the resource is the same object, rebinds, and continues from
> the bytes already on disk.

Adaptive media is treated as independent durable jobs — video + audio +
subtitles download separately, validate, and are muxed losslessly with bundled
FFmpeg. No helper application (Python, Node, FFmpeg, yt-dlp, torrent client)
is ever required from the user; everything ships inside the installer.

## Status

**Phase 0 (foundation) — complete.** See `docs/reports/phase0/` for the
architecture, dependency, and risk reports.

Implemented in Phase 0: monorepo + toolchain, versioned contract system with
cross-language fixture parity, Rust `download-core` process with JSONL
JSON-RPC over stdio + SQLite (WAL) migrations, Electron main with typed IPC +
core supervision/restart, sandboxed preload bridge, React 19 renderer with
Windows 11 dark UI, structured redacting logger, headless smoke test,
resource fetch/verify pipeline, NSIS packaging config, CI.

Roadmap (phases 1–31) is defined in the master build prompt: application
shell → embedded browser → download engine → multi-connection segments →
recovery engine → media extraction (yt-dlp) → muxing → HLS/DASH → subtitles →
proxy → torrent → scheduler → batch/grabber → ad block → hardening.

## Development

```bash
pnpm install          # deps + electron binary
pnpm dev              # vite + esbuild watch + electron
pnpm test             # typecheck + contract tests + rust tests + integration
pnpm smoke            # headless end-to-end smoke (xvfb on linux CI)
```

The Rust core is built automatically for dev via the release binary; if
missing, run `pnpm core:build`.

## Bundled resources

The installer embeds `download-core` (built from source), yt-dlp, Deno, and
FFmpeg/FFprobe. Fetch and pin them with checksums:

```bash
pnpm resources:fetch     # download + sha256 lockfiles
pnpm resources:verify    # offline verification
pnpm dist                # one-command NSIS installer (on Windows)
```

## Documentation

- `AGENTS.md` — binding manual for AI agents working on this repo
- `docs/architecture/` — system, processes, IPC, download engine, recovery
- `docs/adr/` — architecture decision records
- `docs/reports/phase0/` — discovery reports
- `docs/licenses/` — third-party redistribution audit
