import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import process from 'node:process';

// Phase 0 integration test (master prompt §10 acceptance):
//   Electron and Rust successfully exchange a typed health-check message.
// This exercises the exact JSONL JSON-RPC wire contract that the Electron
// main process uses, against the real release binary.

const ROOT = resolve(import.meta.dirname, '../..');
const binaryName = process.platform === 'win32' ? 'download-core.exe' : 'download-core';
const binaryPath = join(ROOT, 'native', 'target', 'release', binaryName);

const exists = (await import('node:fs')).existsSync(binaryPath);
if (!exists) {
  console.error(`core binary not found: ${binaryPath}`);
  console.error('build it first: pnpm core:build');
  process.exit(1);
}

const dataDir = mkdtempSync(join(tmpdir(), 'nimbus-it-'));
const child = spawn(binaryPath, ['--data-dir', dataDir, '--log-level', 'info'], {
  stdio: ['pipe', 'pipe', 'pipe'],
});
child.stderr.on('data', (chunk) => process.stderr.write(`[core] ${chunk}`));

const TIMEOUT_MS = 10_000;
const timeout = setTimeout(() => {
  console.error('FAIL: health check timed out');
  child.kill('SIGKILL');
  process.exit(1);
}, TIMEOUT_MS);

let stdoutBuffer = '';
child.stdout.on('data', (chunk) => {
  stdoutBuffer += String(chunk);
  let newlineIndex;
  while ((newlineIndex = stdoutBuffer.indexOf('\n')) !== -1) {
    const line = stdoutBuffer.slice(0, newlineIndex).trim();
    stdoutBuffer = stdoutBuffer.slice(newlineIndex + 1);
    if (line.length === 0) continue;
    handleResponse(line);
  }
});

function handleResponse(line) {
  let message;
  try {
    message = JSON.parse(line);
  } catch {
    console.error(`FAIL: unparseable core response: ${line.slice(0, 200)}`);
    child.kill('SIGKILL');
    process.exit(1);
    return;
  }

  if (message.error) {
    console.error(`FAIL: core returned error: ${JSON.stringify(message.error)}`);
    finish(1);
    return;
  }

  const result = message.result ?? {};
  const checks = [
    ['name', result.name === 'download-core'],
    ['status', result.status === 'ok'],
    ['pid', Number.isInteger(result.pid) && result.pid > 0],
    ['schemaVersion', result.db?.schemaVersion >= 1],
    ['journalMode', result.db?.journalMode === 'wal'],
    ['version', typeof result.version === 'string' && result.version.length > 0],
    ['time', typeof result.time === 'string' && result.time.endsWith('Z')],
  ];
  let ok = true;
  for (const [name, passed] of checks) {
    console.log(`  ${passed ? 'PASS' : 'FAIL'}  ${name}`);
    if (!passed) ok = false;
  }
  console.log(
    ok ? 'PASS: core health contract verified over JSONL stdio' : 'FAIL: contract mismatch',
  );
  finish(ok ? 0 : 1);
}

function finish(code) {
  clearTimeout(timeout);
  child.kill();
  setTimeout(() => {
    rmSync(dataDir, { recursive: true, force: true });
    process.exit(code);
  }, 200);
}

child.stdin.write(
  `${JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'core.health', params: {} })}\n`,
);

child.on('exit', (code) => {
  if (code !== null && code !== 0 && !child.killed) {
    console.error(`core exited unexpectedly (code=${code})`);
    clearTimeout(timeout);
    process.exit(1);
  }
});
